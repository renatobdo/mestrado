package hivemq.mqtt.client;

import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CountDownLatch;


import com.hivemq.client.mqtt.MqttGlobalPublishFilter;
import com.hivemq.client.mqtt.datatypes.MqttQos;
import com.hivemq.client.mqtt.mqtt5.Mqtt5AsyncClient;
import com.hivemq.client.mqtt.mqtt5.Mqtt5BlockingClient;
import com.hivemq.client.mqtt.mqtt5.Mqtt5Client;
import com.hivemq.client.mqtt.mqtt5.message.connect.connack.Mqtt5ConnAck;
import com.hivemq.client.mqtt.mqtt5.message.disconnect.Mqtt5DisconnectReasonCode;
import com.hivemq.client.mqtt.mqtt5.message.subscribe.Mqtt5RetainHandling;
import com.hivemq.client.mqtt.mqtt5.message.subscribe.suback.Mqtt5SubAck;

public class Publish2 {
	public static void main(String[] args) throws InterruptedException {

		final Mqtt5AsyncClient client = Mqtt5Client.builder()
                .serverHost("177.104.61.27")
                .automaticReconnectWithDefaultConfig()
                .buildAsync();

        final Mqtt5ConnAck connAck = client.toBlocking().connectWith()
                .cleanStart(false)          // resume a previous session
                .sessionExpiryInterval(30)  // keep session state for 30s
                .restrictions()
                    .receiveMaximum(10)             // receive max. 10 concurrent messages
                    .sendMaximum(10)                // send max. 10 concurrent messages
                    .maximumPacketSize(10_240)      // receive messages with max size of 10KB
                    .sendMaximumPacketSize(10_240)  // send messages with max size of 10KB
                    .topicAliasMaximum(0)           // the server should not use topic aliases
                    .sendTopicAliasMaximum(8)       // use up to 8 aliases for the most used topics (automatically traced)
                    .applyRestrictions()
                .willPublish()
                    .topic("iotamanager")
                    .qos(MqttQos.EXACTLY_ONCE)
                    .payload("confirma��o de conex�o enviada do servidor para o cliente".getBytes())
                    .contentType("text/plain")  // our payload is text
                    .messageExpiryInterval(120) // not so important, expire message after 2min if can not be delivered
                    .delayInterval(30)          // delay sending out the will message so we can try to reconnect immediately
                    .userProperties()           // add some user properties to the will message
                        .add("sender", "demo-sender-1")
                        .add("receiver", "you")
                        .applyUserProperties()
                    .applyWillPublish()
                .send();

        System.out.println("connected " + connAck + " connAck values = "+connAck.getType().values());
        

        final Mqtt5SubAck subAck = client.subscribeWith()
                .topicFilter("iotamanager")
                .noLocal(true)                                      // we do not want to receive our own message
                .retainHandling(Mqtt5RetainHandling.DO_NOT_SEND)    // do not send retained messages
                .retainAsPublished(true)                            // keep the retained flag as it was published
                .callback(publish -> System.out.println("received message subAck (confirma��o de subscri��o): " + publish+
                		" Tipo de conte�do (content/type): " + publish.getContentType().toString()))
                .send().join();

        System.out.println("subscribed " + subAck);


        client.toBlocking().publishWith()
                .topic("iotamanager")
                .qos(MqttQos.EXACTLY_ONCE)
                .payload("payload".getBytes())
                .retain(true)
                .contentType("text/plain")  // our payload is text
                .messageExpiryInterval(120) // not so important, expire message after 2min if can not be delivered
                .userProperties()           // add some user properties to the message
                    .add("sender", "demo-sender-1")
                    .add("receiver", "you")
                    .applyUserProperties()
                .send();

        System.out.println("published: we do not receive our own messages");


        // setup a latch to wait for 1 message
        final CountDownLatch countDownLatch = new CountDownLatch(1);
        client.publishes(MqttGlobalPublishFilter.ALL, publish -> countDownLatch.countDown());


        final Mqtt5BlockingClient client2 = Mqtt5Client.builder().serverHost("177.104.61.27").buildBlocking();
        client2.connect();
        client2.publishWith()
                .topic("iotamanager")
                .retain(true)
                .userProperties()
                    .add("sender", "demo-sender-2")
                    .add("receiver", "you")
                    .applyUserProperties()
                .send();
        client2.disconnect();

        System.out.println("client2 published: waiting for message to be received");
        countDownLatch.await();
        System.out.println("received message from client2: see the user property sender, also see that retain=true as requested");

        
        client.toBlocking().disconnectWith()
                .reasonCode(Mqtt5DisconnectReasonCode.DISCONNECT_WITH_WILL_MESSAGE) // send the will message
                .sessionExpiryInterval(0)                                           // we want to clear the session
                .send();

        System.out.println("disconnected");


        System.exit(0);
    }
}
