package de.dcsquare.paho.client.subscriber;

public class Evento implements Context{

	@Override
	public String eventId() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String timestamp() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String eventType() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String resource() {
		// TODO Auto-generated method stub
		return null;
	}

}
