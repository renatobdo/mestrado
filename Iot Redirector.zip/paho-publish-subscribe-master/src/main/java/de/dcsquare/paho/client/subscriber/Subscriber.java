package de.dcsquare.paho.client.subscriber;

import de.dcsquare.paho.client.util.Utils;

import org.bson.Document;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttException;

import com.hivemq.client.mqtt.mqtt5.Mqtt5AsyncClient;
import com.hivemq.client.mqtt.mqtt5.Mqtt5Client;
import com.hivemq.client.mqtt.mqtt5.Mqtt5ClientBuilder;
import com.mongodb.MongoClient;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;

/**
 * @author Dominik Obermaier
 * @author Christian Götz
 */
public class Subscriber {

    //public static final String BROKER_URL = "tcp://177.104.61.114:1883";
	public static final String BROKER_URL = "tcp://177.104.61.126:1883";
	//public static final String BROKER_URL = "tcp://35.202.161.93:1883";

    //We have to generate a unique Client id.
    String clientId = Utils.getMacAddress() + "-sub";
    private MqttClient mqttClient;
   

    public Subscriber() {

        try {
            mqttClient = new MqttClient(BROKER_URL, clientId);
            

        } catch (MqttException e) {
            e.printStackTrace();
            System.exit(1);
        }
    }

    public PubSubMessage start() {
        try {

            mqttClient.setCallback(new SubscribeCallback());
            mqttClient.connect();
            
            

            //Subscribe to all subtopics of home
           // final String topic = "iotamanager";
            final String topic = "#";
            mqttClient.subscribe(topic);

            System.out.println("Subscriber is now listening to "+topic);
            

        } catch (MqttException e) {
            e.printStackTrace();
            System.exit(1);
        }
		return null;
    }

    public static void main(String... args) throws Exception {
        final Subscriber subscriber = new Subscriber();
        subscriber.start();
		/*
		 * MongoClient cliente = new MongoClient(); MongoDatabase bancoDeDados =
		 * cliente.getDatabase("SensorDB"); MongoCollection<Document> iotagents =
		 * bancoDeDados.getCollection("AgentLog"); Document iotagent =
		 * iotagents.find().first(); System.out.println(iotagent); cliente.close();
		 */
        
        
		/*
		 * Evento context = new Evento(); Example Example = new Example();
		 * 
		 * Example.accept(subscriber.start(), context);
		 */
    }

}
