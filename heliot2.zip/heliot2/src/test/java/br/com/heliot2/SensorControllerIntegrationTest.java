package br.com.heliot2;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.client.HttpClientErrorException;

import br.com.heliot2.Application;
import br.com.heliot2.model.Sensor;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = Application.class, webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class SensorControllerIntegrationTest {
	@Autowired
	private TestRestTemplate restTemplate;

	@LocalServerPort
	private int port;

	private String getRootUrl() {
		return "http://localhost:" + port;
	}

	@Test
	public void contextLoads() {

	}

	@Test
	public void testGetAllSensores() {
		HttpHeaders headers = new HttpHeaders();
		HttpEntity<String> entity = new HttpEntity<String>(null, headers);

		ResponseEntity<String> response = restTemplate.exchange(getRootUrl() + "/sensores",
				HttpMethod.GET, entity, String.class);
		
		assertNotNull(response.getBody());
	}

	@Test
	public void testGetSensorById() {
		Sensor sensor = restTemplate.getForObject(getRootUrl() + "/sensores/1", Sensor.class);
		System.out.println(sensor.getName());
		assertNotNull(sensor);
	}

	@Test
	public void testCreateSensor() {
		Sensor sensor = new Sensor();
		sensor.setDescription("O DHT22 é um sensor de temperatura e umidade que permite fazer leituras de temperaturas entre -40 a +80 graus Celsius e umidade entre 0 a 100%");
		sensor.setName("DHT22");
		sensor.setType("Temperatura e Umidade");

		ResponseEntity<Sensor> postResponse = restTemplate.postForEntity(getRootUrl() + "/sensores", sensor, Sensor.class);
		assertNotNull(postResponse);
		assertNotNull(postResponse.getBody());
	}

	@Ignore
	@Test
	public void testUpdateSensor() {
		int id = 1;
		Sensor sensor = restTemplate.getForObject(getRootUrl() + "/sensores/" + id, Sensor.class);
		sensor.setName("admin1");
		sensor.setType("admin2");

		restTemplate.put(getRootUrl() + "/sensores/" + id, sensor);

		Sensor updatedSensor = restTemplate.getForObject(getRootUrl() + "/sensores/" + id, Sensor.class);
		assertNotNull(updatedSensor);
	}

	@Ignore
	@Test
	public void testDeleteSensor() {
		int id = 2;
		Sensor sensor = restTemplate.getForObject(getRootUrl() + "/sensores/" + id, Sensor.class);
		assertNotNull(sensor);

		restTemplate.delete(getRootUrl() + "/sensores/" + id);

		try {
			sensor = restTemplate.getForObject(getRootUrl() + "/sensores/" + id, Sensor.class);
		} catch (final HttpClientErrorException e) {
			assertEquals(e.getStatusCode(), HttpStatus.NOT_FOUND);
		}
	}
}
