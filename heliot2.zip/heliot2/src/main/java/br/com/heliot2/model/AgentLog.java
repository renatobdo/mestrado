package br.com.heliot2.model;


import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.Transient;
import org.springframework.data.mongodb.core.mapping.Document;

@Document (collection = "AgentLog")
public class AgentLog {
	
	@Transient
    public static final String SEQUENCE_NAME = "users_sequence";
	
	@Id
	private long id;
	
	private String contentype;
    
	private String statusCode;
	
	private String payload;
	
	private String description;
	
	private long tempoParsing;
	
	public AgentLog() {
	}
	
	public AgentLog(String contentype, String statusCode, String payload, String description, long tempoParsing) {
		this.contentype = contentype;
		this.statusCode = statusCode;
		this.payload = payload;
		this.description = description;
		this.tempoParsing = tempoParsing;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getContentype() {
		return contentype;
	}

	public void setContentype(String contentype) {
		this.contentype = contentype;
	}
	
	public String getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}
	
	public String getPayload() {
		return payload;
	}

	public void setPayload(String payload) {
		this.payload = payload;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public long getTempoParsing() {
		return tempoParsing;
	}

	public void setTempoParsing(long tempoParsing) {
		this.tempoParsing = tempoParsing;
	}

	@Override
	public String toString() {
		return "AgentLog [id=" + id + ", contentype=" + contentype + ", statusCode=" + statusCode +", payload=" + payload +  ", description=" + description
				+  ", tempoParsing=" + tempoParsing+    "]";
	}
}