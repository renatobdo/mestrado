package br.com.heliot2.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import br.com.heliot2.model.AgentLog;
@Repository
public interface AgentLogRepository extends MongoRepository<AgentLog, Long>{

}
