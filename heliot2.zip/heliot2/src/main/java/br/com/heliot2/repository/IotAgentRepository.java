package br.com.heliot2.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import br.com.heliot2.model.IotAgent;

@Repository
public interface IotAgentRepository extends MongoRepository<IotAgent, Long>{

}