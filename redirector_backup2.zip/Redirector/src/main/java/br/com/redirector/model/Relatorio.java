package br.com.redirector.model;

public class Relatorio {
	private static int contador;
	private static int tipo;
	private static int contadorXML;
	private static int contadorHTML;
	private static int contadorJSON;
	private static int contadorUL;
	private static int contadorAleatorio;
	private static int contadorLora;
	private static int contadorTeros;
	
	public static int getTipo() {
		return tipo;
	}

	public static void setTipo(int tipo) {
		Relatorio.tipo = tipo;
	}

	public static int getContadorXML() {
		return contadorXML;
	}

	public static void setContadorXML(int contadorXML) {
		Relatorio.contadorXML = contadorXML;
	}

	public static int getContadorHTML() {
		return contadorHTML;
	}

	public static void setContadorHTML(int contadorHTML) {
		Relatorio.contadorHTML = contadorHTML;
	}

	public static int getContadorJSON() {
		return contadorJSON;
	}

	public static void setContadorJSON(int contadorJSON) {
		Relatorio.contadorJSON = contadorJSON;
	}

	public static int getContadorUL() {
		return contadorUL;
	}

	public static void setContadorUL(int contadorUL) {
		Relatorio.contadorUL = contadorUL;
	}

	public static int getContadorAleatorio() {
		return contadorAleatorio;
	}

	public static void setContadorAleatorio(int contadorAleatorio) {
		Relatorio.contadorAleatorio = contadorAleatorio;
	}

	public static int getContadorLora() {
		return contadorLora;
	}

	public static void setContadorLora(int contadorLora) {
		Relatorio.contadorLora = contadorLora;
	}

	public static int getContadorTeros() {
		return contadorTeros;
	}

	public static void setContadorTeros(int contadorTeros) {
		Relatorio.contadorTeros = contadorTeros;
	}

	public int getContador() {
		return contador;
	}

	public void setContador(int conta) {
		contador = conta;
	}
	public static int contabiliza() {
		if (tipo == 1) {
			contadorXML++; 
			return contadorXML;
		}else if (tipo == 2) {
			contadorHTML++;
			return contadorHTML;
		}else if (tipo == 3) {
			contadorJSON++;
			return contadorJSON;
		}else if (tipo == 4) {
			contadorUL++;
			return contadorUL;
		}else if (tipo == 5) {
			contadorAleatorio++;
			return contadorAleatorio;
		}else if (tipo == 6) {
			contadorLora++;
			return contadorLora;
		}else if (tipo == 7) {
			contadorTeros++;
			return contadorTeros;
		}
		return 0;
	}
	public static void mostraRelatorio() {
		System.out.println("Contagem de sensores XML = " + contadorXML);
		System.out.println("Contagem de sensores HTML = " + contadorHTML);
		System.out.println("Contagem de sensores JSON = " + contadorJSON);
		System.out.println("Contagem de sensores UL = " + contadorUL);
		System.out.println("Contagem de sensores INDEFINIDO = " + contadorAleatorio);
		System.out.println("Contagem de sensores LoRa = " + contadorLora);
		System.out.println("Contagem de sensores Teros = " + contadorTeros);
	}
	
}
