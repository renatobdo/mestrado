package br.com.redirector.model;

import java.io.IOException;

abstract public class Sensor implements ClimaAPI{
	public int id;
	public String name;
	public String protocolo;
	
	public Sensor(int id, String name) {

		this.id = id;
		this.name = name;
	}
	
	public String getProtocolo() {
		return protocolo;
	}

	public void setProtocolo(String protocolo) {
		this.protocolo = protocolo;
	}

	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public abstract String fornecerPayload() throws IOException;
	

}
