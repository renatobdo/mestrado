package br.com.redirector.controller;

import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;

public class Publisher {
	String ipBroker = "tcp://177.104.61.126:1883";
	String payload;

	public void publica(String payload) throws MqttException {
		this.payload = payload;
		MqttClient client = new MqttClient(this.ipBroker, MqttClient.generateClientId());
		client.connect();
		MqttMessage message = new MqttMessage();
		message.setPayload(this.payload.getBytes());
		client.publish("testes", message);

		System.out.println("\tPayload da mensagem ==== " + this.payload);

		client.disconnect();
		System.out.println("== Mensagem publicada STRING == "+message.toString());
	}

}

