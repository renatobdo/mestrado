package br.com.redirector.model;

import java.io.IOException;
import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.util.Base64;

public class Template {
	private static String tipoTemplate;

	public static String getTipoTemplate() {
		return tipoTemplate;
	}

	public static void setTipoTemplate(String tipoTemplate) {
		Template.tipoTemplate = tipoTemplate;
	}
	
	public String geraTemplate(String tipoDeTemplate, float temperatura1) throws IOException {
		tipoTemplate = tipoDeTemplate;
		String payload = "";
		float temperatura = temperatura1;

		if (tipoTemplate.equals("XML")) {

			payload = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><measure device=\"dht22\" key=\"4jggokgpepnvsb2uv4s40d59ov\"><t value=\"" + temperatura + "\" />"
					+ "<ti value = \"XML\" /></measure>";
			// System.out.println("payload = "+payload);
		} else if (tipoTemplate.equals("HTML")) {

			payload = "<!DOCTYPE html><div id=\"temperature\">" + temperatura + "</div><div id=\"ti\">HTML</div>";
		} else if (tipoTemplate.equals("JSON")) {

			payload = "{\"t\":" + "\"" + temperatura + "\",\"ti\":\"JSON\"}"; // +"\""+ ", \"ti\": \"JSON\"}";
		} else if (tipoTemplate.equals("UL"))
		   { 

			payload = "t|" + temperatura + "|ti|UL";
		} else if (tipoTemplate.equals("INDEFINIDO")) {

			// int id = (int) (this.temperatura);
			// String nameSensorIndefinido = "sensorIndefinido_" + id;
			// SensorIndefinido sensorIndefinido = new SensorIndefinido(id,
			// nameSensorIndefinido);

			// payload = sensorIndefinido.fornecerPayload();
			// payload = sensorIndefinido.fornecerPayload();
			System.out.println("Sensor INDEFINIDO.....");
		} else if (tipoTemplate.equals("LORA")) {

			String loraData = "ts|" + String.valueOf(temperatura);
			String textoSerializado = converteBase64(loraData);
			System.out.println("temperatura serializada ====== "+textoSerializado);
			payload = "{\"applicationID\":\"5\",\"applicationName\":\"mestrado_simulacao\",\"deviceName\":\"DHT11\",\"devEUI\":\"221597e4529df57d\","
					+ "\"rxInfo\":[{\"gatewayID\":\"000000ffff001000\",\"name\":\"ExpGW\",\"rssi\":-57,\"loRaSNR\":7,\"location\":{"
					+ "\"latitude\":0,\"longitude\":0,\"altitude\":0}}],\"txInfo\":{\"frequency\":915000000,\"dr\":5},\"adr\":false,"
					+ "\"fCnt\":0,\"fPort\":1,\"data\":\""+textoSerializado + "\"}";
		} else if (tipoTemplate.equals("TEROS12")) {
			//https://www.baeldung.com/java-checksums
			payload = "	2584.5 " + temperatura + " 136\r\n" + 
					"g8k";
		}
		return payload;
		}
	
	public String formataPayload(String tipoDeTemplate, float temperatura1) throws IOException {
		tipoTemplate = tipoDeTemplate;
		String payload = "";
		float temperatura = temperatura1;

		if (tipoTemplate.equals("XML")) {

			payload = "<measure device=\"dht22\" key=\"4jggokgpepnvsb2uv4s40d59ov\"><t value=\"" + temperatura + "\" />"
					+ "<ti value = \"XML\" /></measure>";
			// System.out.println("payload = "+payload);
		} else if (tipoTemplate.equals("HTML")) {

			payload = "<!DOCTYPE html><div id=\"temperature\">" + temperatura + "</div><div id=\"ti\">HTML</div>";
		} else if (tipoTemplate.equals("JSON")) {

			payload = "{\"t\":" + "\"" + temperatura + "\",\"ti\":\"JSON\"}"; // +"\""+ ", \"ti\": \"JSON\"}";
			
		} else if (tipoTemplate.equals("UL")) {

			payload = "t|" + temperatura + "|ti|UL";
			
		}else if (tipoTemplate.equals("TEROS12")){
			
			payload = "t|" + temperatura + "|ti|TEROS12";
			
		} else if (tipoTemplate.equals("INDEFINIDO")) {

			// int id = (int) (this.temperatura);
			// String nameSensorIndefinido = "sensorIndefinido_" + id;
			// SensorIndefinido sensorIndefinido = new SensorIndefinido(id,
			// nameSensorIndefinido);

			// payload = sensorIndefinido.fornecerPayload();
			// payload = sensorIndefinido.fornecerPayload();
			System.out.println("Sensor INDEFINIDO.....");
		} else if (tipoTemplate.equals("LORA")) {
			
			String loraData = "ts|" + String.valueOf(temperatura);
			String textoSerializado = converteBase64(loraData);
			payload = "{\"applicationID\":\"5\",\"applicationName\":\"mestrado_simulacao\",\"deviceName\":\"DHT11\",\"devEUI\":\"221597e4529df57d\","
					+ "\"rxInfo\":[{\"gatewayID\":\"000000ffff001000\",\"name\":\"ExpGW\",\"rssi\":-57,\"loRaSNR\":7,\"location\":{"
					+ "\"latitude\":0,\"longitude\":0,\"altitude\":0}}],\"txInfo\":{\"frequency\":915000000,\"dr\":5},\"adr\":false,"
					+ "\"fCnt\":0,\"fPort\":1,\"data\":\""+textoSerializado + "\"}";
		}else if (tipoTemplate.equals("LORA2")) {
			DecimalFormat df = new DecimalFormat("#");
			df.setRoundingMode(RoundingMode.FLOOR);
			System.out.println("testes Template === "+df.format(temperatura));
			String loraData = "ts|" + df.format(temperatura) + "|ti|lora";
			String textoSerializado = converteBase64(loraData);
			payload = "{\"applicationID\":\"5\",\"applicationName\":\"mestrado_simulacao\",\"deviceName\":\"DHT11\",\"devEUI\":\"221597e4529df57d\","
					+ "\"rxInfo\":[{\"gatewayID\":\"000000ffff001000\",\"name\":\"ExpGW\",\"rssi\":-57,\"loRaSNR\":7,\"location\":{"
					+ "\"latitude\":0,\"longitude\":0,\"altitude\":0}}],\"txInfo\":{\"frequency\":915000000,\"dr\":5},\"adr\":false,"
					+ "\"fCnt\":0,\"fPort\":1,\"data\":\""+textoSerializado + "\"}";
		}
		return payload;
	}
	private static String converteBase64(String loraData) {

		return Base64.getEncoder().encodeToString(loraData.getBytes());

	}

}
