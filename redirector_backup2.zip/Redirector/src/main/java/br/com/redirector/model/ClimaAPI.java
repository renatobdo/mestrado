package br.com.redirector.model;

public interface ClimaAPI {
	//temperatura USP
	String API_OPENWEATHER_XML = "http://api.openweathermap.org/data/2.5/weather?lat=-23.560420&lon=-46.731370&appid=c7f8bc1d2e8a77746581de0ac142c8b3&units=metric&mode=xml";
	//Temperatura Jardim tres marias - São Bernardo do Campo
	String API_OPENWEATHER_GOOGLE_HTML = "https://www.google.com/search?q=temperatura&sxsrf=ALeKk00RPoOUXMlMQ-mkO6_VK2ZRoIrpLA%3A1628720521142&ei=iU0UYZqLCMC81sQP3puskAI&oq=temperatura&gs_lcp=Cgdnd3Mtd2l6EAMyBAgjECcyBwgAEEcQsAMyBwgAEEcQsAMyBwgAEEcQsAMyBwgAEEcQsAMyBwgAEEcQsAMyBwgAEEcQsAMyBwgAEEcQsAMyBwgAEEcQsANKBAhBGABQnUxYnUxg601oAXACeACAAb8GiAG_BpIBAzYtMZgBAKABAcABAQ&sclient=gws-wiz&ved=0ahUKEwja8-bggKryAhVAnpUCHd4NCyIQ4dUDCA4&uact=5";
	
	//temperatura UFABC - Santo André
	String API_OPENWEATHER_JSON = "http://api.openweathermap.org/data/2.5/weather?lat=-23.646310&lon=-46.527720&appid=c7f8bc1d2e8a77746581de0ac142c8b3&units=metric";
	
	//Temperatura UFABC - São Bernardo do Campo
	String API_OPENWEATHER_UL = "http://api.openweathermap.org/data/2.5/weather?lat=-23.676992&lon=-46.563269&appid=c7f8bc1d2e8a77746581de0ac142c8b3&units=metric";
	//Temperatura de região não especificada (UFABC - Santo André)
	String API_OPENWEATHER_Lora = "http://api.openweathermap.org/data/2.5/weather?lat=-23.646310&lon=-46.527720&appid=c7f8bc1d2e8a77746581de0ac142c8b3&units=metric";
}
