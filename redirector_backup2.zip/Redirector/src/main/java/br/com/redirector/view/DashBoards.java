package br.com.redirector.view;
import static com.mongodb.client.model.Filters.eq;
import java.util.Arrays;
import org.bson.Document;
import com.mongodb.MongoClient;
import com.mongodb.MongoClientURI;
import com.mongodb.client.AggregateIterable;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import org.bson.conversions.Bson;
import java.util.concurrent.TimeUnit;
import org.bson.Document;

public class DashBoards {
	public static void dashBoardTempoParsingPorContenType() {
		MongoClient mongoClient = new MongoClient(
			    new MongoClientURI(
			        "mongodb://localhost:27017/?readPreference=primary&appname=MongoDB%20Compass&directConnection=true&ssl=false"
			    )
			);
			MongoDatabase database = mongoClient.getDatabase("SensorDB");
			MongoCollection<Document> collection = database.getCollection("AgentLog");

			AggregateIterable<Document> result =  collection.aggregate(Arrays.asList(new Document("$group", 
				    new Document("_id", "$contentype")
				            .append("avgtempoParsing", 
				    new Document("$avg", "$tempoParsing")))));
			//https://stackoverflow.com/questions/30424894/java-syntax-with-mongodb
			for (Document document : result) {
			    System.out.println(document);
			}
	}
	public static void dashBoardConsultaTodos() {
		Bson filter = new Document();

		MongoClient mongoClient = new MongoClient(
		    new MongoClientURI(
		        "mongodb://localhost:27017/?readPreference=primary&appname=MongoDB%20Compass&directConnection=true&ssl=false"
		    )
		);
		MongoDatabase database = mongoClient.getDatabase("SensorDB");
		MongoCollection<Document> collection = database.getCollection("AgentLog");
		FindIterable<Document> result = collection.find(filter);
		//https://stackoverflow.com/questions/30424894/java-syntax-with-mongodb
		for (Document document : result) {
		    System.out.println(document);
		}
	}
	public static void dashBoardConsultaPorContenType() {
		Bson filter = eq("contentype", "4");
		
		MongoClient mongoClient = new MongoClient(
		    new MongoClientURI(
		        "mongodb://localhost:27017/?readPreference=primary&appname=MongoDB%20Compass&directConnection=true&ssl=false"
		    )
		);
		MongoDatabase database = mongoClient.getDatabase("SensorDB");
		MongoCollection<Document> collection = database.getCollection("AgentLog");
		FindIterable<Document> result = collection.find(filter);
		//https://stackoverflow.com/questions/30424894/java-syntax-with-mongodb
		for (Document document : result) {
		    System.out.println(document);
		}
	}
	public static void main(String[] args) {
		/*
		 * Requires the MongoDB Java Driver.
		 * https://mongodb.github.io/mongo-java-driver
		 */
		dashBoardTempoParsingPorContenType();
		//dashBoardConsultaTodos();
		//dashBoardConsultaPorContenType();
		
	}
}
