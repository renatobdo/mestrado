package br.com.redirector.model;

public interface IotAgent {
	String url_iotagent_xml = "http://177.104.61.27:7896/iot/xml";
	String url_iotagent_html = "nao existe ainda";
	String url_iotagent_json = "http://177.104.61.27:7897/iot/json?k=4jggokgpepnvsb2uv4s40d59ov&i=dht22";
	String url_iotagent_ul = "http://177.104.61.27:7898/iot/d?k=4jggokgpepnvsb2uv4s40d59ov&i=dht22";
	String url_iotagent_indefinido = "redirecionar para o Iot Agent mais parecido";
	String url_iotagent_lora = "http://177.104.61.27:7898/iot/d?k=4jggokgpepnvsb2uv4s40d59ov&i=dht22";
	String url_local = "http://localhost:8080/api/v1/agentlogs";
	String ipBrokerMqtt = "tcp://177.104.61.27:1883";
	
}
