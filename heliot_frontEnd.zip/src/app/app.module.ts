import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { CreateSensorComponent } from './create-sensor/create-sensor.component';
import { SensorDetailsComponent } from './sensor-details/sensor-details.component';
import { SensorListComponent } from './sensor-list/sensor-list.component';
import { UpdateSensorComponent } from './update-sensor/update-sensor.component';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { IotagentListComponent } from './iotagent-list/iotagent-list.component';
import { CreateIotagentComponent } from './create-iotagent/create-iotagent.component';
import { IotagentDetailsComponent } from './iotagent-details/iotagent-details.component';
import { UpdateIotagentComponent } from './update-iotagent/update-iotagent.component';
import { IotagentlogListComponent } from './iotagentlog-list/iotagentlog-list.component';
import { IotagentlogDetailsComponent } from './iotagentlog-details/iotagentlog-details.component';
import { OrionlogListComponent } from './orionlog-list/orionlog-list.component';

@NgModule({
  declarations: [
    AppComponent,
    CreateSensorComponent,
    SensorDetailsComponent,
    SensorListComponent,
    UpdateSensorComponent,
    IotagentListComponent,
    CreateIotagentComponent,
    IotagentDetailsComponent,
    UpdateIotagentComponent,
    IotagentlogListComponent,
    IotagentlogDetailsComponent,
    OrionlogListComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
