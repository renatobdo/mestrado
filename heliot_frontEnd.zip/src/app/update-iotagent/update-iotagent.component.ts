import { Component, OnInit } from '@angular/core';
import { Iotagent } from '../iotagent';
import { IotagentService } from '../iotagent.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-update-iotagent',
  templateUrl: './update-iotagent.component.html',
  styleUrls: ['./update-iotagent.component.css']
})
export class UpdateIotagentComponent implements OnInit {

  id: number;
  iotagent: Iotagent;
  submitted = false;

  constructor(private route: ActivatedRoute,private router: Router,
    private iotagentService: IotagentService) { }

  ngOnInit() {
    this.iotagent = new Iotagent();

    this.id = this.route.snapshot.params['id'];
    
    this.iotagentService.getIotagent(this.id)
      .subscribe(data => {
        console.log(data)
        this.iotagent = data;
      }, error => console.log(error));
  }

  updateIotagent() {
    this.iotagentService.updateIotagent(this.id, this.iotagent)
      .subscribe(data => console.log(data), error => console.log(error));
    this.iotagent = new Iotagent();
    this.gotoList();
  }

  onSubmit() {
    this.submitted = true;
    this.updateIotagent();    
  }

  gotoList() {
    this.router.navigate(['/employees']);
  }

}
