import { Component, OnInit } from '@angular/core';
import { Sensor } from '../sensor';
import { Router } from '@angular/router';
import { SensorService } from '../sensor.service';

@Component({
  selector: 'app-create-sensor',
  templateUrl: './create-sensor.component.html',
  styleUrls: ['./create-sensor.component.css']
})
export class CreateSensorComponent implements OnInit {

  sensor: Sensor = new Sensor();
  submitted = false;

  constructor(private sensorService: SensorService,
    private router: Router) { }

  ngOnInit() {
  }

  newSensor(): void {
    this.submitted = false;
    this.sensor = new Sensor();
  }

  save() {
    this.sensorService.createSensor(this.sensor)
      .subscribe(data => console.log(data), error => console.log(error));
    this.sensor = new Sensor();
    this.gotoList();
  }

  onSubmit() {
    this.submitted = true;
    this.save();    
  }

  gotoList() {
    this.router.navigate(['/sensors']);
  }

}
