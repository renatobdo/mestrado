import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class IotagentService {
   
  private baseUrl = 'http://localhost:8080/api/v1/iotagents';

  constructor(private http: HttpClient) { }

  getIotagent(id: number): Observable<any> {
    return this.http.get(`${this.baseUrl}/${id}`);
  }
  createIotagent(iotagent: Object): Observable<Object> {
    return this.http.post(`${this.baseUrl}`, iotagent);
  }
  
  updateIotagent(id: number, value: any): Observable<Object> {
    return this.http.put(`${this.baseUrl}/${id}`, value);
  }

  deleteIotagent(id: number): Observable<any> {
    return this.http.delete(`${this.baseUrl}/${id}`, { responseType: 'text' });
  }

  getIotagentsList(): Observable<any> {
    return this.http.get(`${this.baseUrl}`);
  }
  

}