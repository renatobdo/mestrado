import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CreateIotagentComponent } from './create-iotagent.component';

describe('CreateIotagentComponent', () => {
  let component: CreateIotagentComponent;
  let fixture: ComponentFixture<CreateIotagentComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CreateIotagentComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CreateIotagentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
