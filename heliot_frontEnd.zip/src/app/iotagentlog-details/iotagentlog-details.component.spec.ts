import { ComponentFixture, TestBed } from '@angular/core/testing';

import { IotagentlogDetailsComponent } from './iotagentlog-details.component';

describe('IotagentlogDetailsComponent', () => {
  let component: IotagentlogDetailsComponent;
  let fixture: ComponentFixture<IotagentlogDetailsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ IotagentlogDetailsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(IotagentlogDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
