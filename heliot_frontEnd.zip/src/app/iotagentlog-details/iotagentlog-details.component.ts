import { Component, OnInit } from '@angular/core';
import { Iotagentlog } from '../iotagentlog';
import { ActivatedRoute, Router } from '@angular/router';
import { IotagentlogService } from '../iotagentlog.service';

@Component({
  selector: 'app-iotagentlog-details',
  templateUrl: './iotagentlog-details.component.html',
  styleUrls: ['./iotagentlog-details.component.css']
})
export class IotagentlogDetailsComponent implements OnInit {

  id: number;
  iotagentlog: Iotagentlog;

  constructor(private route: ActivatedRoute, private router: Router,
    private iotagentlogService: IotagentlogService) { }

  ngOnInit() {
    this.iotagentlog = new Iotagentlog();

    this.id = this.route.snapshot.params['id'];

    this.iotagentlogService.getIotagentlog(this.id)
      .subscribe(data => {
        console.log(data)
        this.iotagentlog = data;
      }, error => console.log(error));
  }

  listiotagentlogs() {
    this.router.navigate(['agentlogs']);
  }
  
}
