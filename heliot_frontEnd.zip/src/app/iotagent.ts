export class Iotagent {
    id: number;
    name: string;
    type: string;
    description: string;
}