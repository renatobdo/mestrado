import { Component, OnInit } from '@angular/core';
import { IotagentService } from '../iotagent.service';
import { ActivatedRoute, Router } from '@angular/router';
import { Iotagent } from '../iotagent';

@Component({
  selector: 'app-iotagent-details',
  templateUrl: './iotagent-details.component.html',
  styleUrls: ['./iotagent-details.component.css']
})
export class IotagentDetailsComponent implements OnInit {

  id: number;
  iotagent: Iotagent;

  constructor(private route: ActivatedRoute, private router: Router,
    private iotagentService: IotagentService) { }

  ngOnInit() {
    this.iotagent = new Iotagent();

    this.id = this.route.snapshot.params['id'];

    this.iotagentService.getIotagent(this.id)
      .subscribe(data => {
        console.log(data)
        this.iotagent = data;
      }, error => console.log(error));
  }

  listiotagents() {
    this.router.navigate(['iotagents']);
  }

}
