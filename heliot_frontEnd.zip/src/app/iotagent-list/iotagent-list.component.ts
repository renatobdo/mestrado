
import { Observable } from 'rxjs';
import { IotagentService } from '../iotagent.service';
import { Iotagent } from '../iotagent';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-iotagent-list',
  templateUrl: './iotagent-list.component.html',
  styleUrls: ['./iotagent-list.component.css']
})
export class IotagentListComponent implements OnInit {

  iotagents: Observable<Iotagent[]>;  

  constructor(private iotagentService: IotagentService,
    private router: Router) { }

  ngOnInit() {
    this.reloadData();
  }

  reloadData() {
    this.iotagents = this.iotagentService.getIotagentsList();
  }                                       

  deleteIotagent(id: number) {
    this.iotagentService.deleteIotagent(id)
      .subscribe(
        data => {
          console.log(data);
          this.reloadData();
        },
        error => console.log(error));
  }

  iotagentDetails(id: number) {
    this.router.navigate(['detailsiotagent', id]);
  }

  updateIotagent(id: number){
    this.router.navigate(['update', id]);
  }

}
