import { TestBed } from '@angular/core/testing';

import { IotagentlogService } from './iotagentlog.service';

describe('IotagentlogService', () => {
  let service: IotagentlogService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(IotagentlogService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
