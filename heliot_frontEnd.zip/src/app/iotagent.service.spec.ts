import { TestBed } from '@angular/core/testing';

import { IotagentService } from './iotagent.service';

describe('IotagentService', () => {
  let service: IotagentService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(IotagentService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
