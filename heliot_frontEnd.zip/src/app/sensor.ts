export class Sensor {
    id: number;
    name: string;
    type: string;
    description: string;
}