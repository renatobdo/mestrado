import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { Orionlog } from '../orionlog';
import { Router } from '@angular/router';
import { OrionlogService } from '../orionlog.service';

@Component({
  selector: 'app-orionlog-list',
  templateUrl: './orionlog-list.component.html',
  styleUrls: ['./orionlog-list.component.css']
})
export class OrionlogListComponent implements OnInit {
  orionlogs: Observable<Orionlog[]>; 
  constructor(private orionlogService: OrionlogService,
    private router: Router) { }

  ngOnInit() {
    this.reloadData();
  }

  reloadData() {
    this.orionlogs = this.orionlogService.getOrionlogList();
  }                                       
  
  deleteIotagentlog(id: number) {
    this.orionlogService.deleteOrionlog(id)
      .subscribe(
        data => {
          console.log(data);
          this.reloadData();
        },
        error => console.log(error));
  }
  
  orionlogDetails(id: number) {
    this.router.navigate(['orionlogDetails', id]);
  }
 
  updateOrionlog(id: number){
    this.router.navigate(['updateorionlog', id]);
  }

}
