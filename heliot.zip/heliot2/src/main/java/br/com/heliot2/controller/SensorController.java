package br.com.heliot2.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import br.com.heliot2.exception.ResourceNotFoundException;
import br.com.heliot2.model.Sensor;
import br.com.heliot2.repository.SensorRepository;
import br.com.heliot2.service.SequenceGeneratorService;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/api/v1")
public class SensorController {
	@Autowired
	private SensorRepository sensorRepository;
	
	@Autowired
	private SequenceGeneratorService sequenceGeneratorService;

	@GetMapping("/sensors")
	public List<Sensor> getAllSensors() {
		return sensorRepository.findAll();
	}

	@GetMapping("/sensors/{id}")
	public ResponseEntity<Sensor> getSensorById(@PathVariable(value = "id") Long sensorId)
			throws ResourceNotFoundException {
		Sensor sensor = sensorRepository.findById(sensorId)
				.orElseThrow(() -> new ResourceNotFoundException("Sensor not found for this id :: " + sensorId));
		return ResponseEntity.ok().body(sensor);
	}

	@PostMapping("/sensors")
	public Sensor createSensor(@Valid @RequestBody Sensor sensor) {
		sensor.setId(sequenceGeneratorService.generateSequence(Sensor.SEQUENCE_NAME));
		return sensorRepository.save(sensor);
	}

	@PutMapping("/sensors/{id}")
	public ResponseEntity<Sensor> updateSensor(@PathVariable(value = "id") Long sensorId,
			@Valid @RequestBody Sensor sensorDetails) throws ResourceNotFoundException {
		Sensor sensor = sensorRepository.findById(sensorId)
				.orElseThrow(() -> new ResourceNotFoundException("Sensor not found for this id :: " + sensorId));

		sensor.setId(sensorDetails.getId());
		sensor.setName(sensorDetails.getName());
		sensor.setType(sensorDetails.getType());
		sensor.setDescription(sensorDetails.getDescription());
		final Sensor updatedSensor = sensorRepository.save(sensor);
		return ResponseEntity.ok(updatedSensor);
	}

	@DeleteMapping("/sensors/{id}")
	public Map<String, Boolean> deleteSensor(@PathVariable(value = "id") Long sensorId)
			throws ResourceNotFoundException {
		Sensor sensor = sensorRepository.findById(sensorId)
				.orElseThrow(() -> new ResourceNotFoundException("Sensor not found for this id :: " + sensorId));

		sensorRepository.delete(sensor);
		Map<String, Boolean> response = new HashMap<>();
		response.put("deleted", Boolean.TRUE);
		return response;
	}
}
