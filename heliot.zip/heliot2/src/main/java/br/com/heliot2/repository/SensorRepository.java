package br.com.heliot2.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import br.com.heliot2.model.Sensor;

@Repository
public interface SensorRepository extends MongoRepository<Sensor, Long>{

}
