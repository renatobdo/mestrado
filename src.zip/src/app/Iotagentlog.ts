export class Iotagentlog {
    id: number;
    contentype: string;
    payload: string;
    description: string;
}