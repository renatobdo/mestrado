import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class IotagentlogService {

  private baseUrl = 'http://localhost:8080/api/v1/agentlogs';

  constructor(private http: HttpClient) { }

  getIotagentlog(id: number): Observable<any> {
    return this.http.get(`${this.baseUrl}/${id}`);
  }
  createIotagentlog(iotagent: Object): Observable<Object> {
    return this.http.post(`${this.baseUrl}`, iotagent);
  }
  
  updateIotagentlog(id: number, value: any): Observable<Object> {
    return this.http.put(`${this.baseUrl}/${id}`, value);
  }

  deleteIotagentlog(id: number): Observable<any> {
    return this.http.delete(`${this.baseUrl}/${id}`, { responseType: 'text' });
  }

  getIotagentslogList(): Observable<any> {
    return this.http.get(`${this.baseUrl}`);
  }
}
