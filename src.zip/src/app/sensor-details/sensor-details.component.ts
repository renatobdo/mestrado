import { Component, OnInit } from '@angular/core';
import { Sensor } from '../sensor';
import { ActivatedRoute, Router } from '@angular/router';
import { SensorService } from '../sensor.service';

@Component({
  selector: 'app-sensor-details',
  templateUrl: './sensor-details.component.html',
  styleUrls: ['./sensor-details.component.css']
})
export class SensorDetailsComponent implements OnInit {

  id: number;
  sensor: Sensor;

  constructor(private route: ActivatedRoute,private router: Router,
    private sensorService: SensorService) { }

  ngOnInit() {
    this.sensor = new Sensor();

    this.id = this.route.snapshot.params['id'];
    
    this.sensorService.getSensor(this.id)
      .subscribe(data => {
        console.log(data)
        this.sensor = data;
      }, error => console.log(error));
  }

  list(){
    this.router.navigate(['sensors']);
  }

}
