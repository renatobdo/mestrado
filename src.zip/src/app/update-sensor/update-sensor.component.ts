import { Component, OnInit } from '@angular/core';
import { Sensor } from '../sensor';
import { ActivatedRoute, Router } from '@angular/router';
import { SensorService } from '../sensor.service';

@Component({
  selector: 'app-update-sensor',
  templateUrl: './update-sensor.component.html',
  styleUrls: ['./update-sensor.component.css']
})
export class UpdateSensorComponent implements OnInit {

  id: number;
  sensor: Sensor;

  constructor(private route: ActivatedRoute,private router: Router,
    private sensorService: SensorService) { }

  ngOnInit() {
    this.sensor = new Sensor();

    this.id = this.route.snapshot.params['id'];
    
    this.sensorService.getSensor(this.id)
      .subscribe(data => {
        console.log(data)
        this.sensor = data;
      }, error => console.log(error));
  }

  updateSensor() {
    this.sensorService.updateSensor(this.id, this.sensor)
      .subscribe(data => console.log(data), error => console.log(error));
    this.sensor = new Sensor();
    this.gotoList();
  }

  onSubmit() {
    this.updateSensor();    
  }

  gotoList() {
    this.router.navigate(['/sensors']);
  }

}
