import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SensorListComponent } from './sensor-list/sensor-list.component';
import { CreateSensorComponent } from './create-sensor/create-sensor.component';
import { UpdateSensorComponent } from './update-sensor/update-sensor.component';
import { SensorDetailsComponent } from './sensor-details/sensor-details.component';
import { IotagentListComponent } from './iotagent-list/iotagent-list.component';
import { CreateIotagentComponent } from './create-iotagent/create-iotagent.component';
import { UpdateIotagentComponent } from './update-iotagent/update-iotagent.component';
import { IotagentDetailsComponent } from './iotagent-details/iotagent-details.component';
import { IotagentlogListComponent } from './iotagentlog-list/iotagentlog-list.component';
import { IotagentlogDetailsComponent } from './iotagentlog-details/iotagentlog-details.component';

const routes: Routes = [
  { path: '', redirectTo: 'sensor', pathMatch: 'full' },
  { path: 'sensors', component: SensorListComponent },
  { path: 'iotagents', component: IotagentListComponent },
  { path: 'agentlogs', component: IotagentlogListComponent },

  { path: 'add', component: CreateSensorComponent },  
  { path: 'addiotagents', component: CreateIotagentComponent },  
  
  { path: 'update/:id', component: UpdateSensorComponent },
  { path: 'updateiotagent/:id', component: UpdateIotagentComponent },

  { path: 'details/:id', component: SensorDetailsComponent },
  { path: 'detailsiotagent/:id', component: IotagentDetailsComponent },
  { path: 'iotagentlogDetails/:id', component: IotagentlogDetailsComponent },
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
