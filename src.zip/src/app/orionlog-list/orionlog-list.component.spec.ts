import { ComponentFixture, TestBed } from '@angular/core/testing';

import { OrionlogListComponent } from './orionlog-list.component';

describe('OrionlogListComponent', () => {
  let component: OrionlogListComponent;
  let fixture: ComponentFixture<OrionlogListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ OrionlogListComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(OrionlogListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
