import { ComponentFixture, TestBed } from '@angular/core/testing';

import { IotagentDetailsComponent } from './iotagent-details.component';

describe('IotagentDetailsComponent', () => {
  let component: IotagentDetailsComponent;
  let fixture: ComponentFixture<IotagentDetailsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ IotagentDetailsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(IotagentDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
