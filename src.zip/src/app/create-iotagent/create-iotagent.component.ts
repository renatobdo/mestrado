import { IotagentService } from '../iotagent.service';
import { Iotagent } from '../iotagent';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-create-iotagent',
  templateUrl: './create-iotagent.component.html',
  styleUrls: ['./create-iotagent.component.css']
})
export class CreateIotagentComponent implements OnInit {

  iotagent: Iotagent = new Iotagent();
  submitted = false;

  constructor(private iotagentService: IotagentService,
    private router: Router) { }

  ngOnInit() {
  }

  newIotagent(): void {
    this.submitted = false;
    this.iotagent = new Iotagent();
  }

  save() {
    this.iotagentService.createIotagent(this.iotagent)
      .subscribe(data => console.log(data), error => console.log(error));
    this.iotagent = new Iotagent();
    this.gotoList();
  }

  onSubmit() {
    this.submitted = true;
    this.save();    
  }

  gotoList() {
    this.router.navigate(['/iotagents']);
  }

}
