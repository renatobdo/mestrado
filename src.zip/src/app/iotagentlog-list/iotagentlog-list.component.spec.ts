import { ComponentFixture, TestBed } from '@angular/core/testing';

import { IotagentlogListComponent } from './iotagentlog-list.component';

describe('IotagentlogListComponent', () => {
  let component: IotagentlogListComponent;
  let fixture: ComponentFixture<IotagentlogListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ IotagentlogListComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(IotagentlogListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
