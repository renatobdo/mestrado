import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { Router } from '@angular/router';
import { IotagentlogService } from '../iotagentlog.service';
import { Iotagentlog } from '../iotagentlog';

@Component({
  selector: 'app-iotagentlog-list',
  templateUrl: './iotagentlog-list.component.html',
  styleUrls: ['./iotagentlog-list.component.css']
})
export class IotagentlogListComponent implements OnInit {

  iotagentlogs: Observable<Iotagentlog[]>;  

  constructor(private iotagentlogService: IotagentlogService,
    private router: Router) { }

  ngOnInit() {
    this.reloadData();
  }

  reloadData() {
    this.iotagentlogs = this.iotagentlogService.getIotagentslogList();
  }                                       
  
  deleteIotagentlog(id: number) {
    this.iotagentlogService.deleteIotagentlog(id)
      .subscribe(
        data => {
          console.log(data);
          this.reloadData();
        },
        error => console.log(error));
  }
  
  iotagentlogDetails(id: number) {
    this.router.navigate(['iotagentlogDetails', id]);
  }
 
  updateIotagentlog(id: number){
    this.router.navigate(['updateiotagentlog', id]);
  }

}
