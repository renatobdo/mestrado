export class Orionlog {
    id: number;
    temperatura: string;
    ti: string;
}