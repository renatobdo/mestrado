import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdateIotagentComponent } from './update-iotagent.component';

describe('UpdateIotagentComponent', () => {
  let component: UpdateIotagentComponent;
  let fixture: ComponentFixture<UpdateIotagentComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UpdateIotagentComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UpdateIotagentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
