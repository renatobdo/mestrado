import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class SensorService {

  
  private baseUrl = 'http://localhost:8080/api/v1/sensors';

  constructor(private http: HttpClient) { }

  getSensor(id: number): Observable<any> {
    return this.http.get(`${this.baseUrl}/${id}`);
  }

  createSensor(sensor: Object): Observable<Object> {
    return this.http.post(`${this.baseUrl}`, sensor);
  }

  updateSensor(id: number, value: any): Observable<Object> {
    return this.http.put(`${this.baseUrl}/${id}`, value);
  }

  deleteSensor(id: number): Observable<any> {
    return this.http.delete(`${this.baseUrl}/${id}`, { responseType: 'text' });
  }

  getSensorsList(): Observable<any> {
    return this.http.get(`${this.baseUrl}`);
  }

}
