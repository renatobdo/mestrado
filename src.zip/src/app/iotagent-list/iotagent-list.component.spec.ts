import { ComponentFixture, TestBed } from '@angular/core/testing';

import { IotagentListComponent } from './iotagent-list.component';

describe('IotagentListComponent', () => {
  let component: IotagentListComponent;
  let fixture: ComponentFixture<IotagentListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ IotagentListComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(IotagentListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
