package hivemq.mqtt.client;

import java.util.UUID;
import java.util.concurrent.TimeUnit;

import com.hivemq.client.mqtt.MqttClient;
import com.hivemq.client.mqtt.datatypes.MqttQos;
import com.hivemq.client.mqtt.mqtt5.Mqtt5Client;
import com.hivemq.client.mqtt.mqtt5.Mqtt5RxClient;
import com.hivemq.client.mqtt.mqtt5.message.connect.Mqtt5Connect;
import com.hivemq.client.mqtt.mqtt5.message.publish.Mqtt5Publish;

import io.reactivex.Completable;
import io.reactivex.Flowable;

public class Publish {
	public static void main(String[] args) {
		Mqtt5RxClient client = Mqtt5Client.builder().identifier(UUID.randomUUID().toString())
				.serverHost("177.104.61.27").buildRx();

		// As we use the reactive API, the following line does not connect yet, but
		// returns a reactive type.
		Completable connectScenario = client.connect()
				.doOnSuccess(connAck -> System.out.println("Connected, " + connAck.getReasonCode()))
				.doOnError(throwable -> System.out.println("Connection failed, " + throwable.getMessage()))
				.ignoreElement();

		// Fake a stream of Publish messages with an incrementing number in the payload
		/*
		 * Flowable<Mqtt5Publish> messagesToPublish = Flowable.range(0, 100) .map(i ->
		 * Mqtt5Publish.builder().topic("iotamanager").qos(MqttQos.AT_LEAST_ONCE)
		 * .payload(
		 * ("1|<measure device=\"motion001\" key=\"4jggokgpepnvsb2uv4s40d59ov\">\r\n" +
		 * "	<c value=\"9\"/>\r\n" + "</measure> " + i).getBytes())
		 * .contentType("XML").build()) // Emit 1 message only every 100 milliseconds
		 * .zipWith(Flowable.interval(10000, TimeUnit.MILLISECONDS), (publish, i) ->
		 * publish);
		 */

		Flowable<Mqtt5Publish> messagesToPublish = Flowable.range(0, 100)
				.map(i -> Mqtt5Publish.builder().topic("iotamanager").qos(MqttQos.AT_LEAST_ONCE)
						.payload(("<measure device=\"motion001\" key=\"4jggokgpepnvsb2uv4s40d59ov\">\n\t<c value=\"3\"/>\n</measure>" + i).getBytes())
						.contentType("UL").build())
				// Emit 1 message only every 100 milliseconds
				.zipWith(Flowable.interval(10000, TimeUnit.MILLISECONDS), (publish, i) -> publish);
		// As we use the reactive API, the following line does not publish yet, but
		// returns a reactive type.
		Completable publishScenario = client.publish(messagesToPublish)
				.doOnNext(publishResult -> System.out
						.println("Publish acknowledged: " + new String(publishResult.getPublish().getPayloadAsBytes())))
				.ignoreElements();

		// As we use the reactive API, the following line does not disconnect yet, but
		// returns a reactive type.
		Completable disconnectScenario = client.disconnect().doOnComplete(() -> System.out.println("Disconnected"));

		// Reactive types can be easily and flexibly combined
		connectScenario.andThen(publishScenario).andThen(disconnectScenario).blockingAwait();

	}

}
