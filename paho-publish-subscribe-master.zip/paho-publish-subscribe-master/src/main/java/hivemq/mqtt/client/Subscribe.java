package hivemq.mqtt.client;

import java.io.ObjectInputStream.GetField;
import java.util.UUID;
import java.util.concurrent.Callable;

import javax.annotation.Nonnull;

import org.apache.commons.lang3.Validate;
import org.reactivestreams.Subscriber;

import com.hivemq.client.mqtt.MqttGlobalPublishFilter;
import com.hivemq.client.mqtt.datatypes.MqttQos;
import com.hivemq.client.mqtt.mqtt5.Mqtt5AsyncClient;
import com.hivemq.client.mqtt.mqtt5.Mqtt5AsyncClient.Mqtt5SubscribeAndCallbackBuilder;
import com.hivemq.client.mqtt.mqtt5.Mqtt5BlockingClient;
import com.hivemq.client.mqtt.mqtt5.Mqtt5Client;
import com.hivemq.client.mqtt.mqtt5.Mqtt5ClientConfig;
import com.hivemq.client.mqtt.mqtt5.Mqtt5RxClient;
import com.hivemq.client.mqtt.mqtt5.message.Mqtt5MessageType;
import com.hivemq.client.mqtt.mqtt5.message.connect.connack.Mqtt5ConnAck;
import com.hivemq.client.mqtt.mqtt5.message.publish.Mqtt5Publish;
import com.hivemq.client.mqtt.mqtt5.message.publish.Mqtt5PublishBuilder.Complete;
import com.hivemq.client.mqtt.mqtt5.message.subscribe.Mqtt5Subscribe;
import com.hivemq.client.mqtt.mqtt5.message.subscribe.suback.Mqtt5SubAck;
import com.hivemq.client.rx.FlowableWithSingle;
import com.mashape.unirest.http.HttpResponse;
import com.mashape.unirest.http.Unirest;
import com.mashape.unirest.http.exceptions.UnirestException;

import de.dcsquare.paho.client.subscriber.SubscribeCallback;
import io.opencensus.stats.View;
import io.reactivex.Completable;
import io.reactivex.CompletableSource;
import io.reactivex.Notification;
import io.reactivex.Single;
import io.reactivex.functions.Action;
import io.reactivex.functions.BiConsumer;
import io.reactivex.functions.Consumer;
import io.reactivex.functions.Function;
import io.reactivex.functions.Predicate;

public class Subscribe {
	public static void main(String[] args) throws UnirestException {
		Mqtt5RxClient client = Mqtt5Client.builder().identifier(UUID.randomUUID().toString())
				.serverHost("177.104.61.27").buildRx();

		// As we use the reactive API, the following line does not connect yet, but
		// returns a reactive type.
		// e.g. Single is something like a lazy and reusable future. Think of it as a
		// source for the ConnAck message.
		Single<Mqtt5ConnAck> connAckSingle = client.connect();

		// Same here: the following line does not subscribe yet, but returns a reactive
		// type.
		// FlowableWithSingle is a combination of the single SubAck message and a
		// Flowable of Publish messages.
		// A Flowable is an asynchronous stream that enables backpressure from the
		// application over the client to the broker.
		FlowableWithSingle<Mqtt5Publish, Mqtt5SubAck> subAckAndMatchingPublishes = client.subscribeStreamWith()
				.topicFilter("iotamanager").qos(MqttQos.AT_LEAST_ONCE).addSubscription().topicFilter("iotamanager")
				.qos(MqttQos.EXACTLY_ONCE).applySubscription().applySubscribe();

		// The reactive types offer many operators that will not be covered here.
		// Here we register callbacks to print messages when we received the CONNACK,
		// SUBACK and matching PUBLISH messages.
		Completable connectScenario = connAckSingle
				.doOnSuccess(connAck -> System.out.println("Connected, " + connAck.getReasonCode()))
				.doOnError(throwable -> System.out.println("Connection failed, " + throwable.getMessage()))
				.ignoreElement();

		// System.out.println("Oi Renato"+ subAckAndMatchingPublishes.toList());

		Unirest.setTimeouts(0, 0);
		/*
		 * HttpResponse<String> response =
		 * Unirest.post("http://177.104.61.27:7896/iot/xml") .header("Content-Type",
		 * "application/xml")
		 * .body("<measure device=\"motion001\" key=\"4jggokgpepnvsb2uv4s40d59ov\">\n\t<c value=\"4\"/>\n</measure>"
		 * ) .asString();
		 */

		/*
		 * if (response.equals("201")) { System.out.println("201 ok"); }else {
		 * System.out.println("imprimindo a response..."+response.getStatus()); }
		 */

		/*
		 * Completable subscribeScenario = subAckAndMatchingPublishes .doOnSingle(subAck
		 * -> System.out.println("Subscribed, " + subAck.getReasonCodes()))
		 * .doOnNext(publish -> System.out.println("Received publish" + ", topic: " +
		 * publish.getTopic() + ", QoS: " + publish.getQos() + ", payload: " + new
		 * String(publish.getPayloadAsBytes()) + "Content type = " +
		 * publish.getContentType())
		 * 
		 * )
		 * 
		 * .ignoreElements();
		 */

		Completable subscribeScenario = subAckAndMatchingPublishes
				.doOnSingle(subAck -> System.out.println("Subscribed, " + subAck.getReasonCodes()))
				// .doOnEach(verificaContentType(subAckAndMatchingPublishes))
				.doOnNext(publish -> System.out.println("payload = " + new String(publish.getPayloadAsBytes())
						+ " content type = " + publish.getContentType()))
				.doAfterNext(publish2 -> Unirest
						.post("http://35.199.98.23:7896/iot/d?k=4jggokgpepnvsb2uv4s40d59ov&i=motion001")
						.header("Content-Type", "text/plain").body(publish2.getPayloadAsBytes()).asString())

				.ignoreElements();
		// client.connect().subscribeWith(observer)
		System.out.println("client.connectWith().willPublish()" + client.connectWith().willPublish());
		// System.out.println("client.connectWith().willPublish()"+subAckAndMatchingPublishes.all(verificaContent()));

		System.out.println("client.getState() = " + Mqtt5MessageType.values().toString());
		// Reactive types can be easily and flexibly combined
		connectScenario.andThen(subscribeScenario).blockingAwait();
	}

	private static boolean verificaContent() {

		String contentType = "XML";
		// TODO Auto-generated method stub
		// contentType.toString();
		if (Mqtt5Publish.builder().topic("iotamanager").contentType(contentType).equals("XML")) {
			return true;
		} else {
			return false;
		}
	}

	/*
	 * private static Consumer<? super Notification<Mqtt5Publish>>
	 * verificaContentType(FlowableWithSingle<Mqtt5Publish, Mqtt5SubAck>
	 * subAckAndMatchingPublishes) { // TODO Auto-generated method stub
	 * 
	 * }
	 */

}
