package de.dcsquare.paho.client.subscriber;

import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;

import org.eclipse.paho.client.mqttv3.*;

import com.mashape.unirest.http.HttpResponse;
import com.mashape.unirest.http.JsonNode;
import com.mashape.unirest.http.Unirest;

/**
 * @author Dominik Obermaier
 * @author Christian Götz
 */
public class SubscribeCallback implements MqttCallback {

	public void connectionLost(Throwable cause) {
		// This is called when the connection is lost. We could reconnect here.
	}

	public static String trataDados(String dado) {
		dado = dado.replaceAll("\"", "");
		// dado = dado.replaceAll(" ", "");
		return dado;
	}

	public static String trataDadosJson(String dado) {
		dado = dado.replace("}", ",\"ti\":\"json\"z");
		// dado = dado.replaceAll(" ", "");
		return dado;
	}

	public static String trataDadosJson2(String dado) {
		dado = dado.replace("z", "}");
		// dado = dado.replaceAll(" ", "");
		return dado;
	}

	public void messageArrived(String topic, MqttMessage message) throws Exception {
		Unirest.setTimeouts(0, 0);
		SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss");
		Date hora = Calendar.getInstance().getTime(); // Ou qualquer outra forma que tem
		String dataFormatada = sdf.format(hora);

		System.out.println("Mensagem chegando ao topico: " + topic + " - Hor�rio: " + dataFormatada + "  Message: "
				+ message.toString());

		/*
		 * if ("home/LWT".equals(topic)) { System.err.println("Sensor gone!"); }
		 */
		String mensagem = message.toString();
		// System.out.println(message.toString());
		// System.out.println("Mensagem = "+ mensagem);
//https://www.w3schools.com/java/ref_string_contains.asp
		// https://www.latlong.net/ Alameda Da Universidade, S/N - Anchieta, S�o
		// Bernardo Do Campo - SP, 09606-045
		/*
		 * if (mensagem.substring(0, 1).contentEquals("1")) {
		 * System.out.println("1 = XML");
		 * System.out.println("mensagem.substring(0,1) = " + mensagem.substring(0, 1));
		 * } else if (mensagem.substring(0, 1).contentEquals("2")) {
		 * System.out.println("2 = HTML");
		 * System.out.println("mensagem.substring(0,1) = " + mensagem.substring(0, 1));
		 * } else if (mensagem.substring(0, 1).contentEquals("3")) {
		 * System.out.println("3 = JSON");
		 * System.out.println("mensagem.substring(0,1) = " + mensagem.substring(0, 1));
		 * } else if (mensagem.substring(0, 1).contentEquals("4")) {
		 * System.out.println("4 = UL"); System.out.println("mensagem.substring(0,1) = "
		 * + mensagem.substring(0, 1)); } else if (mensagem.substring(0,
		 * 1).contentEquals("5")) { System.out.println("5 = nda");
		 * System.out.println("mensagem.substring(0,1) = " + mensagem.substring(0, 1));
		 * }
		 */

		System.out.println("mensagem.substring(1) = " + mensagem.substring(1));
		if (mensagem.substring(1).contains("<")) {
			// try {
			// if (mensagem.contains("DOCTYPE html")) {
			// System.out.println("Content-type HTML");

			// } else {
			System.out.println("Content-type baseado em XML");
			try {
				HttpResponse<String> response = Unirest.post("http://177.104.61.27:7896/iot/xml")
						.header("Content-Type", "application/xml")
						.body(mensagem.substring(1) + "<ti value = \"XML\" /></measure>").asString();
			//	System.out.println(mensagem.substring(1) + "<ti value = \"XMS\" /></measure>");
				System.out.println("response XML = " + response.getStatus());

			} catch (Exception e) {
				System.out.println("Algo deu errado! erro = " + e.getMessage());

				System.out.println("Causa do erro " + e.getCause());
			} finally {
				System.out.println("O 'try catch' do tratamento XML finalizou.");
			}
			
			// }
			// } catch (Exception ex) {
			// System.out.println("Exce��o = "+ex);
			// }

		} else if (mensagem.contains("|")) {
			System.out.println("Content-type baseado em UL");
			try {
				HttpResponse<String> response = Unirest
						 .post("http://35.247.252.230:7896/iot/d?k=4jggokgpepnvsb2uv4s40d59ov&i=dht22")
						// .post("http://192.168.99.100:7896/iot/d?k=4jggokgpepnvsb2uv4s40d59ov&i=temp002")
						//.post("http://192.168.99.100:7896/iot/d?k=4jggokgpepnvsb2uv4s40d59ov&i=dht22")
						.header("Content-Type", "text/plain").body(mensagem.substring(1) + "|ti|UL").asString();
				System.out.println("response UL = "+response.getStatus());
			} catch (Exception e) {
				System.out.println("Algo deu errado! erro = " + e.getMessage());
				// System.out.println("response JSON = " + response.getStatus());
				System.out.println("Causa do erro " + e.getCause());
			} finally {
				System.out.println("O 'try catch' do tratamento UL finalizou.");
			}

		} else if (mensagem.contains("{")) {
			// String mensagemtratada = trataDados(mensagem);
			int z = mensagem.substring(1).length();
			System.out.println("Content-type baseado em JSON");
			//System.out.println("mensagem.substring(1) = " + z);
			String mensagemtratada = trataDadosJson(mensagem);
			String mensagemtratada2 = trataDadosJson2(mensagemtratada);

			//System.out.println("mensagem tratada 2 = " + mensagemtratada2);

			try {
				HttpResponse<String> response = Unirest
						
						.post("http://35.247.252.230:7896/iot/json?k=4jggokgpepnvsb2uv4s40d59ov&i=dht22")
						.header("Content-Type", "application/json")

						.body(mensagemtratada2.substring(1)).asString();

				/*
				 * .body("{\r\n    \"contentype\":\"" + mensagemtratada.substring(0, 1) +
				 * "\",\r\n    \"payload\":\"" + mensagemtratada.substring(1) +
				 * "\",\r\n    \"description\":\"hor�rio:" + dataFormatada +
				 * "\"\r\n}").asString();
				 */
				System.out.println("response JSON = "+response.getStatus());
			} catch (Exception e) {
				System.out.println("Algo deu errado! erro = " + e.getMessage());
				// System.out.println("response JSON = " + response.getStatus());
				System.out.println("Causa do erro " + e.getCause());
			} finally {
				System.out.println("O 'try catch' do tratamento JSON finalizou.");
			}

		} else {
			System.out.println("Protocolo n�o identificado, n�o foi poss�vel realizar o redirecionamento");
		}

		// https://www.alura.com.br/artigos/trocando-caracteres-de-uma-string-no-java#:~:text=Precisamos%20sumir%20com%20os%20caracteres,que%20passarmos%20por%20outro%20caractere.
		String mensagemtratada = trataDados(mensagem);
		System.out.println("mensagem tratada = " + mensagemtratada.substring(1));
		System.out.println("{\r\n    \"id\":21,\r\n    " + "\"contentype\":\"" + mensagemtratada.substring(0, 1)
				+ "\",\r\n    " + "\"payload\":\"" + mensagemtratada.substring(1) + "\",\r\n    "
				+ "\"description\":\" hor�rio: " + dataFormatada + " \"\r\n}");
		// int contador = contador + 1;

		try {

			Unirest.setTimeouts(0, 0);
			HttpResponse<String> response2 = Unirest.post("http://localhost:8080/api/v1/agentlogs")
					.header("Content-Type", "application/json") //
					.body("{\r\n    \"contentype\":\"" + mensagemtratada.substring(0, 1) + "\",\r\n    \"payload\":\""
							+ mensagemtratada.substring(1) + "\",\r\n    \"description\":\"hor�rio:" + dataFormatada
							+ "\"\r\n}")
					.asString();

		} catch (Exception e) {
			System.out.println("Algo deu errado! erro = " + e.getMessage());
		} finally {
			System.out.println("O 'try catch' do tratamento de dados local finalizou.");
		}

		/*
		 * String[] payloadSeparado = mensagem.split("|");
		 * 
		 * String payloadSemProtocolo[] = payloadSeparado; String protocolo =
		 * payloadSeparado[0];
		 */
		/*
		 * for (int i = 1; i < payloadSeparado.length; i++) { payloadSemProtocolo[i] =
		 * payloadSeparado[i]; System.out.println("payloadSeparado["+i+"] = "+
		 * payloadSeparado[i]); System.out.println("payloadSemProtocolo["+i+"] = "+
		 * payloadSeparado[i]);
		 * 
		 * }
		 */
		// System.out.println("Payload da mensagem = "+message);
		// System.out.println("testes "+mensagem.substring(2));
		/*
		 * 08/09/2020 if (payloadSeparado[0].contentEquals("<")){ String
		 * payloadsemprotocolo = payloadSeparado[2];
		 * System.out.println("Verdadeiro "+payloadSeparado[0]);
		 * Unirest.post("http://177.104.61.27:7896/iot/xml") .header("Content-Type",
		 * "application/xml") .body(mensagem.substring(2)).asString(); }else if
		 * (payloadSeparado[0].contentEquals("2")) {
		 * System.out.println("falso "+payloadSeparado[0]); Unirest.post(
		 * "http://35.199.98.23:7896/iot/d?k=4jggokgpepnvsb2uv4s40d59ov&i=motion001")
		 * .header("Content-Type", "text/plain") .body(mensagem.substring(2))
		 * .asString(); }
		 */

		// System.out.println("payload = "+message.getPayload().toString());
		// System.out.println("Qos = "+message.getQos());
		// System.out.println("GetClass = "+message.getClass());
		// System.out.println("Qos = "+message.isRetained());
		// System.out.println("Hashcode = "+message.hashCode());
		// System.out.println(message);
		// String msgDecode = new String(message.getPayload(), "UTF-8");
		// System.out.println("Mensagem decodificada = "+msgDecode);

	}

	public void deliveryComplete(IMqttDeliveryToken token) {
		// no-op
		System.out.println(token);
	}
}
