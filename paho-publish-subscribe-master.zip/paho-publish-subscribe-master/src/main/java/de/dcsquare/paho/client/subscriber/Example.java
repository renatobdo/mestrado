package de.dcsquare.paho.client.subscriber;

import java.util.Base64;
import java.util.Map;
import java.util.logging.Logger;

public class Example implements BackgroundFunction<PubSubMessage> {
	private static final Logger logger = Logger.getLogger(Example.class.getName());

	/*
	 * @Override public void accept(PubSubMessage message, Context context) { String
	 * data = message.data != null ? new
	 * String(Base64.getDecoder().decode(message.data)) : "Hello, World";
	 * logger.info(data); }
	 */
	@Override
	public void accept(de.dcsquare.paho.client.subscriber.PubSubMessage message, Context context) throws Exception {
		// TODO Auto-generated method stub
		String data = message.data != null ? new String(Base64.getDecoder().decode(message.data)) : "Hello, World";
		logger.info(data);
		System.out.println(data); 

	}

	public static class PubSubMessage {
		String data;
		Map<String, String> attributes;
		String messageId;
		String publishTime;
		
	}
	


}