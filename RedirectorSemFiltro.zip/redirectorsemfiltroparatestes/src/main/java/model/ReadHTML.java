package model;

import java.io.IOException;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;

public class ReadHTML {
	public static void main(String[] args) throws IOException {
		//https://jsoup.org/download
		final String GOOGLE_API = "https://www.google.com/search?q=temperatura&sxsrf=ALeKk00RPoOUXMlMQ-mkO6_VK2ZRoIrpLA%3A1628720521142&ei=iU0UYZqLCMC81sQP3puskAI&oq=temperatura&gs_lcp=Cgdnd3Mtd2l6EAMyBAgjECcyBwgAEEcQsAMyBwgAEEcQsAMyBwgAEEcQsAMyBwgAEEcQsAMyBwgAEEcQsAMyBwgAEEcQsAMyBwgAEEcQsAMyBwgAEEcQsANKBAhBGABQnUxYnUxg601oAXACeACAAb8GiAG_BpIBAzYtMZgBAKABAcABAQ&sclient=gws-wiz&ved=0ahUKEwja8-bggKryAhVAnpUCHd4NCyIQ4dUDCA4&uact=5";
		Document doc = Jsoup.connect(GOOGLE_API).get();
		
		Element temperatura = doc.getElementById("wob_tm");
		String tempHTMLtestes = temperatura.text();
		System.out.println("Temperatura String= "+tempHTMLtestes);
		float tempHTML2 = Float.parseFloat(tempHTMLtestes);
		System.out.println("Temperatura = "+temperatura.text());
		System.out.println("Temperatura float= "+tempHTML2);
		
		
	}
}
