package model;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Scanner;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

public class SensorJSON extends Sensor {

	private float temperatura;
	private float humidade;

	public SensorJSON(int id, String name) {
		super(id, name);
		// TODO Auto-generated constructor stub
	}

	public float getTemperatura() throws MalformedURLException {

		String url = API_OPENWEATHER_JSON;
		URL urlfinal = new URL(url);
		try {

			HttpURLConnection conn = (HttpURLConnection) urlfinal.openConnection();
			conn.setRequestMethod("GET");
			conn.connect();

			int responsecode = conn.getResponseCode();

			if (responsecode != 200) {
				throw new RuntimeException("HttpResponseCode: " + responsecode);
			} else {
				String payload = "";
				Scanner scanner = new Scanner(urlfinal.openStream());

				// Write all the JSON data into a string using a scanner
				while (scanner.hasNext()) {
					payload += scanner.nextLine();
				}

				// Close the scanner
				scanner.close();
				// Using the JSON simple library parse the string into a json object
				JSONParser parse = new JSONParser();
				JSONObject data_obj = (JSONObject) parse.parse(payload);

				// Get the required object from the above created object
				JSONObject obj = (JSONObject) data_obj.get("main");
				// System.out.println("Temperatura em JSON = " + obj.get("temp"));
				setTemperatura(Float.parseFloat(obj.get("temp").toString()));
								
				// Close the scanner
				return this.temperatura;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return this.temperatura;

	}

	public void setTemperatura(float d) {
		this.temperatura = d;
	}

	public float getHumidade() {
		return humidade;
	}

	public void setHumidade(float humidade) {
		this.humidade = humidade;
	}

	@Override
	public String fornecerPayload() throws IOException {
		// TODO Auto-generated method stub
		String url = API_OPENWEATHER_JSON;
		String payload = "";
		URL urlfinal;
		try {
			urlfinal = new URL(url);
			HttpURLConnection conn = (HttpURLConnection) urlfinal.openConnection();
			conn.setRequestMethod("GET");
			conn.connect();

			int responsecode = conn.getResponseCode();

			if (responsecode != 200) {
				throw new RuntimeException("HttpResponseCode: " + responsecode);
			} else {
				
				Scanner scanner = new Scanner(urlfinal.openStream());

				// Write all the JSON data into a string using a scanner
				while (scanner.hasNext()) {
					payload += scanner.nextLine();
				}

				// Close the scanner
				scanner.close();
				
				return payload;
			}
		} catch (MalformedURLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		return payload;
	}

}
