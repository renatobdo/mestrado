package model;

import java.io.InputStream;
import java.net.URL;
import java.net.URLConnection;

import javax.xml.XMLConstants;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

public class SensorXML extends Sensor {
	private float temperatura;
	private float humidade;
//	private static final String OPENWEATHER_API = "http://api.openweathermap.org/data/2.5/weather?lat=-23.560420&lon=-46.731370&appid=c7f8bc1d2e8a77746581de0ac142c8b3&units=metric&mode=xml";
	private final DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();

	public SensorXML(int i, String nameSensorXML) {
		super(i, nameSensorXML);
		
		// TODO Auto-generated constructor stub
		// this.setTemperatura(this.getXML());
	}
	
	

	public float getTemperatura() {
		float result = 0;
		String url = API_OPENWEATHER_XML;
		try {
			URLConnection conn = new URL(url).openConnection();
			try (InputStream is = conn.getInputStream()) {
				// unknown XML better turn on this
				dbf.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
				DocumentBuilder dBuilder = dbf.newDocumentBuilder();
				Document doc = dBuilder.parse(is);
				Element element = doc.getDocumentElement();
				// find this tag "temperature"
				NodeList nodeList = element.getElementsByTagName("temperature");
				if (nodeList.getLength() > 0) {
					Element elementAttribute = (Element) nodeList.item(0);
					String temperatura = elementAttribute.getAttribute("value");
					// se n�o estiver vazio...
					if (!"".equals(temperatura)) {
						result = Float.parseFloat(temperatura);
				//		System.out.println(!"".equals(temperatura));
				//		System.out.println("temperatura " + result);
					} else {
						System.out.println("temperatura esta vazia ...");
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw new IllegalArgumentException("Invalid request for domain : " + url);
		}
		this.setTemperatura(result);
		return this.temperatura;
	}

	public void setTemperatura(float temperatura) {
		this.temperatura = temperatura;
	}

	public float getHumidade() {
		return humidade;
	}

	public void setHumidade(float humidade) {
		this.humidade = humidade;
	}

	@Override
	public String fornecerPayload() {
		String payloadXML;
		String url = API_OPENWEATHER_XML;

		URLConnection conn;
		try {
			conn = new URL(url).openConnection();

			// https://stackoverflow.com/questions/2310139/how-to-read-xml-response-from-a-url-in-java
			try (InputStream is = conn.getInputStream()) {
				String str = "";
				int i;
				while ((i = is.read()) != -1) {
					str += String.valueOf((char) i);
				}
				payloadXML = str;
			//	System.out.println(" TESTANDO 2==================" + str);
				// unknown XML better turn on this

			}
		} catch (Exception e) {
			e.printStackTrace();
			throw new IllegalArgumentException("Invalid request for domain : " + url);
		}
		return payloadXML;
	}
}
