package model;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Base64;
import java.util.Scanner;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

public class SensorLora extends Sensor {
	private float temperatura;
	private float humidade;
	private String payload;
	private String loraData;


	public SensorLora(int id, String name) {
		super(id, name);
		// TODO Auto-generated constructor stub
	}

	public float getTemperatura() throws MalformedURLException {
		String url = API_OPENWEATHER_Lora;
		URL urlfinal = new URL(url);
		try {

			HttpURLConnection conn = (HttpURLConnection) urlfinal.openConnection();
			conn.setRequestMethod("GET");
			conn.connect();

			int responsecode = conn.getResponseCode();

			if (responsecode != 200) {
				throw new RuntimeException("HttpResponseCode: " + responsecode);
			} else {
				String payload = "";
				Scanner scanner = new Scanner(urlfinal.openStream());

				// Write all the JSON data into a string using a scanner
				while (scanner.hasNext()) {
					payload += scanner.nextLine();
				}

				// Close the scanner
				scanner.close();
				// Using the JSON simple library parse the string into a json object
				JSONParser parse = new JSONParser();
				JSONObject data_obj = (JSONObject) parse.parse(payload);

				// Get the required object from the above created object
				JSONObject obj = (JSONObject) data_obj.get("main");
				// System.out.println("Temperatura em JSON = " + obj.get("temp"));
				setTemperatura(Float.parseFloat(obj.get("temp").toString()));
				// Close the scanner
				// String payload =
				// "{\"applicationID\":\"5\",\"applicationName\":\"application\",\"deviceName\":\"device\",\"devEUI\":\"221597e4529df57d\",\"txInfo\":{\"frequency\":868300000,\"dr\":1},\"adr\":false,\"fCnt\":0,\"fPort\":1,\"data\":\""+this.temperatura+"\"}";
				return this.temperatura;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return this.temperatura;
	}

	public void setTemperatura(float d) {
		this.temperatura = d;
	}

	public float getHumidade() {
		return humidade;
	}

	public void setHumidade(float humidade) {
		this.humidade = humidade;
	}

	@Override
	public String fornecerPayload() throws IOException {
		String url = API_OPENWEATHER_Lora;
		URL urlfinal = new URL(url);
		try {
			String payload = "";
			HttpURLConnection conn = (HttpURLConnection) urlfinal.openConnection();
			conn.setRequestMethod("GET");
			conn.connect();

			int responsecode = conn.getResponseCode();

			if (responsecode != 200) {
				throw new RuntimeException("HttpResponseCode: " + responsecode);
			} else {
				payload = "";
				Scanner scanner = new Scanner(urlfinal.openStream());

				// Write all the JSON data into a string using a scanner
				while (scanner.hasNext()) {
					payload += scanner.nextLine();
				}

				// Close the scanner
				scanner.close();
				// Using the JSON simple library parse the string into a json object
				JSONParser parse = new JSONParser();
				JSONObject data_obj = (JSONObject) parse.parse(payload);

				// Get the required object from the above created object
				JSONObject obj = (JSONObject) data_obj.get("main");
				// System.out.println("Temperatura em JSON = " + obj.get("temp"));
				setTemperatura(Float.parseFloat(obj.get("temp").toString()));
				// Close the scanner
				String loraData = "ts|"+String.valueOf(this.getTemperatura());
				//https://dicasdejava.com.br/java-como-encriptar-e-desecriptar-uma-string-em-base64/
				
				String textoSerializado = converteBase64(loraData);
				
				
				this.payload = "6{\"applicationID\":\"5\",\"applicationName\":\"mestrado_simulacao\",\"deviceName\":\"DHT11\",\"devEUI\":\"221597e4529df57d\"," + 
						"\"rxInfo\":[{\"gatewayID\":\"000000ffff001000\",\"name\":\"ExpGW\",\"rssi\":-57,\"loRaSNR\":7,\"location\":{" + 
						"\"latitude\":0,\"longitude\":0,\"altitude\":0}}],\"txInfo\":{\"frequency\":915000000,\"dr\":5},\"adr\":false," + 
						"\"fCnt\":0,\"fPort\":1,\"data\":\"" + textoSerializado +
						"}";
				return this.payload;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	//	return payload;
		return this.payload;
	}

	private String converteBase64(String loraData) {
		return this.loraData = Base64.getEncoder().encodeToString(loraData.getBytes());
		
	}
}
