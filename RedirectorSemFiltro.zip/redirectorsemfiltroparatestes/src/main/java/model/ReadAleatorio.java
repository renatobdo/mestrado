package model;

public class ReadAleatorio {
	public static void main(String[] args) throws InterruptedException {
		long totalTime = 12000; // em milisegundos
		long startTime = System.currentTimeMillis();
		boolean toFinish = false;
		int i = 0;
		while (!toFinish) {
			System.out.println("get = " + i++);
			//https://stackoverflow.com/questions/26700265/random-choice-equivalent-in-java-for-an-array
			String[] available_cards = {"<measure dev=\"dht22\" key=\"4jggokgpepnvsb2uv4s40d59ov\"><t value=\"20.45\" />",
					"<measure device=\"dht22\" k=\"4jggokgpepnvsb2uv4s40d59ov\"><t value=\"20.45\" />",
					"<measure device=\"dht22\" key=\"4jggokgpepnvsb2uv4s40d59ov\"><temp value=\"20.45\" />",
					"<measure device=\"dht22\" key=\"4jggokgpepnvsb2uv4s40d59ov\"><t value=\"20.45\"",
					"<measure device=\"dht22\"><t value=\"20.45\" />",
					"<key=\"4jggokgpepnvsb2uv4s40d59ov\"><t value=\"20.45\" />",
					"<measure device=\"dht22\" key=\"4jggokgpepnvsb2uv4s40d59ov\"><value=\"20.45\" />",
					"<measure device=dht22><t value=\"20.45\" />",
					"<div title=Current Temperature>17�C</div>",
					"<!DOCTYPE html><div>17�C</div>",
					"<!DOCTYPE html><div title=Current Temperature>17�C",
					"\"t\":\"12.71\"}",
					"{:\"12.71\"}",
					"{\"t\"\"12.71\"}",
					"{\"t\":\"12.71\"",
					"{\"tempe\":\"12.71\"}",
					"|12.55",
					"t|",
					"t12.55",
					"tempo|12.55",
					"{applicationI:5,applicationName:mestrado_simulacao,deviceName:DHT11,devEUI:221597e4529df57d,rxInfo:[{gatewayID:000000ffff001000,name:ExpGW,rssi:-57,loRaSNR:7,location:{latitude:0,longitude:0,altitude:0}}],txInfo:{frequency:915000000,dr:5},adr:false,fCnt:0,fPort:1,data:dHN8MTYyNjk3OTc0OTgwNA==}",
					"{applicationID:5,applicationNam:mestrado_simulacao,deviceName:DHT11,devEUI:221597e4529df57d,rxInfo:[{gatewayID:000000ffff001000,name:ExpGW,rssi:-57,loRaSNR:7,location:{latitude:0,longitude:0,altitude:0}}],txInfo:{frequency:915000000,dr:5},adr:false,fCnt:0,fPort:1,data:dHN8MTYyNjk3OTc0OTgwNA==}",
					"{applicationID:5,applicationName:mestrado_simulacao,devName:DHT11,devEUI:221597e4529df57d,rxInfo:[{gatewayID:000000ffff001000,name:ExpGW,rssi:-57,loRaSNR:7,location:{latitude:0,longitude:0,altitude:0}}],txInfo:{frequency:915000000,dr:5},adr:false,fCnt:0,fPort:1,data:dHN8MTYyNjk3OTc0OTgwNA==}",
					"{applicationID:5,applicationName:mestrado_simulacao,deviceName:DHT11,devEI:221597e4529df57d,rxInfo:[{gatewayID:000000ffff001000,name:ExpGW,rssi:-57,loRaSNR:7,location:{latitude:0,longitude:0,altitude:0}}],txInfo:{frequency:915000000,dr:5},adr:false,fCnt:0,fPort:1,data:dHN8MTYyNjk3OTc0OTgwNA==}",
					"{applicationID:5,applicationName:mestrado_simulacao,deviceName:DHT11,devEUI:221597e4529df57d,rxInfo:[{gateway:000000ffff001000,name:ExpGW,rssi:-57,loRaSNR:7,location:{latitude:0,longitude:0,altitude:0}}],txInfo:{frequency:915000000,dr:5},adr:false,fCnt:0,fPort:1,data:dHN8MTYyNjk3OTc0OTgwNA==}",
					"{applicationName:mestrado_simulacao,deviceName:DHT11,devEUI:221597e4529df57d,rxInfo:[{gatewayID:000000ffff001000,name:ExpGW,rssi:-57,loRaSNR:7,location:{latitude:0,longitude:0,altitude:0}}],txInfo:{frequency:915000000,dr:5},adr:false,fCnt:0,fPort:1,data:dHN8MTYyNjk3OTc0OTgwNA==}",
					"{applicationID:5,deviceName:DHT11,devEUI:221597e4529df57d,rxInfo:[{gatewayID:000000ffff001000,name:ExpGW,rssi:-57,loRaSNR:7,location:{latitude:0,longitude:0,altitude:0}}],txInfo:{frequency:915000000,dr:5},adr:false,fCnt:0,fPort:1,data:dHN8MTYyNjk3OTc0OTgwNA==}",
					"{applicationID:5,applicationName:mestrado_simulacao,devEUI:221597e4529df57d,rxInfo:[{gatewayID:000000ffff001000,name:ExpGW,rssi:-57,loRaSNR:7,location:{latitude:0,longitude:0,altitude:0}}],txInfo:{frequency:915000000,dr:5},adr:false,fCnt:0,fPort:1,data:dHN8MTYyNjk3OTc0OTgwNA==}",
					"{applicationID:5,applicationName:mestrado_simulacao,deviceName:DHT11,rxInfo:[{gatewayID:000000ffff001000,name:ExpGW,rssi:-57,loRaSNR:7,location:{latitude:0,longitude:0,altitude:0}}],txInfo:{frequency:915000000,dr:5},adr:false,fCnt:0,fPort:1,data:dHN8MTYyNjk3OTc0OTgwNA==}",
					"{applicationID:5,applicationName:mestrado_simulacao,deviceName:DHT11,devEUI:221597e4529df57d,rxInfo:[{name:ExpGW,rssi:-57,loRaSNR:7,location:{latitude:0,longitude:0,altitude:0}}],txInfo:{frequency:915000000,dr:5},adr:false,fCnt:0,fPort:1,data:dHN8MTYyNjk3OTc0OTgwNA==}",
					"{applicationID:5,applicationName:mestrado_simulacao,deviceName:DHT11,devEUI:221597e4529df57d,rxInfo:[{gatewayID:000000ffff001000,rssi:-57,loRaSNR:7,location:{latitude:0,longitude:0,altitude:0}}],txInfo:{frequency:915000000,dr:5},adr:false,fCnt:0,fPort:1,data:dHN8MTYyNjk3OTc0OTgwNA==}",
					"{applicationID:5,applicationName:mestrado_simulacao,deviceName:DHT11,devEUI:221597e4529df57d,rxInfo:[{gatewayID:000000ffff001000,name:ExpGW,rssi:-57,loRaSNR:7,location:{latitude:0,longitude:0,altitude:0}}],txInfo:{frequency:915000000,dr:5},adr:false,fCnt:0,fPort:1}"};  
			java.util.Random random = new java.util.Random();
			int random_computer_card = random.nextInt(available_cards.length);
			System.out.println(available_cards[random_computer_card]);
			
			

			toFinish = (System.currentTimeMillis() - startTime >= totalTime);
			System.out.println("Tempo atual em milisegundos: " + System.currentTimeMillis());
			System.out.println("Tempo de in�cio: " + startTime);
			System.out.println("Tempo total para que finalize = " + totalTime);
			System.out.println("Tempo para encerramento: " + (System.currentTimeMillis() - startTime));
			// Aqui eu coloco de quanto em quanto tempo ser� realizada a requisi��o.
			// Nesse caso a cada 3segundos ir� fazer a requisi��o.
			Thread.sleep(1000);
		}
		
	}
	
}
