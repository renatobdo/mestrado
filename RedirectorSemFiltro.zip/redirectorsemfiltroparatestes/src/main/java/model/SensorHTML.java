package model;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

import org.jsoup.Jsoup;

public class SensorHTML extends Sensor{
	private final String USER_AGENT= "Mozilla/5.0";
	private float temperatura;
	private float humidade;
	
	
	public SensorHTML(int i, String nameSensorHTML) {
		super(i, nameSensorHTML);
		// TODO Auto-generated constructor stub
	}
	
	public float getTemperatura() throws IOException {
		org.jsoup.nodes.Document doc = Jsoup.connect(API_OPENWEATHER_GOOGLE_HTML).get();
		org.jsoup.nodes.Element tempHTML = doc.getElementById("wob_tm");
		String tempHTML2 = tempHTML.text();
		float tempHTML3 = Float.parseFloat(tempHTML2);
		this.setTemperatura(tempHTML3);
		return this.temperatura;
	}
	public void setTemperatura(float temperatura) {
		this.temperatura = temperatura;
		
		
	}
	public float getHumidade() {
		return humidade;
	}
	public void setHumidade(float humidade) {
		this.humidade = humidade;
	}

	//o payload vem com muita informação e o GET eh muito demorado. Talvez seja desnecessário...
	@Override
	public String fornecerPayload() throws IOException{
//		org.jsoup.nodes.Document doc = Jsoup.connect(API_OPENWEATHER_GOOGLE_HTML).get();
		//	String payload = doc.text().toString();
			
			URL obj = new URL(API_OPENWEATHER_GOOGLE_HTML);
	        HttpURLConnection con = (HttpURLConnection) obj.openConnection();

	        // optional default is GET
	        con.setRequestMethod("GET");

	      //add request header
	        con.setRequestProperty("User-Agent", USER_AGENT);

	        int responseCode = con.getResponseCode();
	        System.out.println("\nSending 'GET' request to URL : " + API_OPENWEATHER_GOOGLE_HTML);
	        System.out.println("Response Code : " + responseCode);

	        BufferedReader in = new BufferedReader(
	                new InputStreamReader(con.getInputStream()));
	        String inputLine;
	        StringBuffer response = new StringBuffer();

	        while ((inputLine = in.readLine()) != null) {
	            response.append(inputLine);
	        }
	        in.close();

	        //print result
	      //  System.out.println(response.toString());
	    
			String payload = response.toString();
			
			
			
			return payload;
	}
	
}
