package model;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Scanner;
import java.util.*;
import java.util.concurrent.ThreadLocalRandom;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

public class SensorIndefinido extends Sensor {
	private float temperatura;
	private float humidade;

	public SensorIndefinido(int id, String name) {
		super(id, name);
		// TODO Auto-generated constructor stub
	}

	public float getTemperatura() throws MalformedURLException {

		
		return this.temperatura = 0;

	}

	public void setTemperatura(double d) {
		this.temperatura = (float) d;
	}

	public float getHumidade() {
		return humidade;
	}

	public void setHumidade(float humidade) {
		this.humidade = humidade;
	}

	@Override
	public String fornecerPayload() throws IOException {
		// TODO Auto-generated method stub
		String payload = "";
		String[] listaDeValoresInvalidos = {"<?xml version=\"1.0\" encoding=\"UTF-8\"?><measure dev=\"dht22\" key=\"4jggokgpepnvsb2uv4s40d59ov\"><t value=\"20.45\" />",
				"<?xml version=\"1.0\" encoding=\"UTF-8\"?><measure device=\"dht22\" key=\"4jggokgpepnvsb2uv4s40d59ov\"><temp value=\"20.45\" />",
				"<?xml version=\"1.0\" encoding=\"UTF-8\"?><measure device=\"dht22\" key=\"4jggokgpepnvsb2uv4s40d59ov\"><t value=\"20.45\"",
				"<?xml version=\"1.0\" encoding=\"UTF-8\"?><measure device=\"dht22\"><t value=\"20.45\" />",
				"<?xml version=\"1.0\" encoding=\"UTF-8\"?><key=\"4jggokgpepnvsb2uv4s40d59ov\"><t value=\"20.45\" />",
				"<?xml version=\"1.0\" encoding=\"UTF-8\"?><measure device=\"dht22\" key=\"4jggokgpepnvsb2uv4s40d59ov\"><value=\"20.45\" />",
				"<measure device=dht22><t value=\"20.45\" />",
				"<measure device=\"dht22\"><t value=\"20.45\" />",
				"<measure device=\"dht22\" key=\"4jggokgpepnvsb2uv4s40d59ov\"><value=\"20.45\" />",
				"<measure device=\"dht22\" key=\"4jggokgpepnvsb2uv4s40d59ov\"><temp value=\"20.45\" />",
				"<div title=Current Temperature>17°C</div>",
				"<div title=Current Temperature>17C</div>",
				"<div title=Current Temperature>17</div>",
				"<!DOCTYPE html><div>17°C</div>",
				"<!DOCTYPE html><div title=Current Temperature>17°C",
				"<!DOCTYPE html><div title=Current Temperature>17°C</div>",
				"<div title=Current Temperature>17K</div>",
				"<div html>25</div>",
				"\"t\":\"12.71\"}",
				"\"t\"\"12.71\"}",
				"{:\"12.71\"}",
				"{\"t\"\"12.71\"}",
				"{\"t\":\"12.71\"",
				"{\"tempe\":\"12.71\"}",
				"{\"ti\":\"12.71\"}",
				"|12.55",
				"t|",
				"t12.55",
				"t12.55|T",
				"t12.55|t|2",
				"t|t|2",
				"tempo|12.55",
				"tempo|12.55|t",
				"{applicationI:5,applicationName:mestrado_simulacao,deviceName:DHT11,devEUI:221597e4529df57d,rxInfo:[{gatewayID:000000ffff001000,name:ExpGW,rssi:-57,loRaSNR:7,location:{latitude:0,longitude:0,altitude:0}}],txInfo:{frequency:915000000,dr:5},adr:false,fCnt:0,fPort:1,data:dHN8MTYyNjk3OTc0OTgwNA==}",
				"{applicationID:5,applicationNam:mestrado_simulacao,deviceName:DHT11,devEUI:221597e4529df57d,rxInfo:[{gatewayID:000000ffff001000,name:ExpGW,rssi:-57,loRaSNR:7,location:{latitude:0,longitude:0,altitude:0}}],txInfo:{frequency:915000000,dr:5},adr:false,fCnt:0,fPort:1,data:dHN8MTYyNjk3OTc0OTgwNA==}",
				"{applicationID:5,applicationName:mestrado_simulacao,devName:DHT11,devEUI:221597e4529df57d,rxInfo:[{gatewayID:000000ffff001000,name:ExpGW,rssi:-57,loRaSNR:7,location:{latitude:0,longitude:0,altitude:0}}],txInfo:{frequency:915000000,dr:5},adr:false,fCnt:0,fPort:1,data:dHN8MTYyNjk3OTc0OTgwNA==}",
				"{applicationID:5,applicationName:mestrado_simulacao,deviceName:DHT11,devEI:221597e4529df57d,rxInfo:[{gatewayID:000000ffff001000,name:ExpGW,rssi:-57,loRaSNR:7,location:{latitude:0,longitude:0,altitude:0}}],txInfo:{frequency:915000000,dr:5},adr:false,fCnt:0,fPort:1,data:dHN8MTYyNjk3OTc0OTgwNA==}",
				"{applicationID:5,applicationName:mestrado_simulacao,deviceName:DHT11,devEUI:221597e4529df57d,rxInfo:[{gateway:000000ffff001000,name:ExpGW,rssi:-57,loRaSNR:7,location:{latitude:0,longitude:0,altitude:0}}],txInfo:{frequency:915000000,dr:5},adr:false,fCnt:0,fPort:1,data:dHN8MTYyNjk3OTc0OTgwNA==}",
				"{applicationName:mestrado_simulacao,deviceName:DHT11,devEUI:221597e4529df57d,rxInfo:[{gatewayID:000000ffff001000,name:ExpGW,rssi:-57,loRaSNR:7,location:{latitude:0,longitude:0,altitude:0}}],txInfo:{frequency:915000000,dr:5},adr:false,fCnt:0,fPort:1,data:dHN8MTYyNjk3OTc0OTgwNA==}",
				"{applicationID:5,deviceName:DHT11,devEUI:221597e4529df57d,rxInfo:[{gatewayID:000000ffff001000,name:ExpGW,rssi:-57,loRaSNR:7,location:{latitude:0,longitude:0,altitude:0}}],txInfo:{frequency:915000000,dr:5},adr:false,fCnt:0,fPort:1,data:dHN8MTYyNjk3OTc0OTgwNA==}",
				"{applicationID:5,applicationName:mestrado_simulacao,devEUI:221597e4529df57d,rxInfo:[{gatewayID:000000ffff001000,name:ExpGW,rssi:-57,loRaSNR:7,location:{latitude:0,longitude:0,altitude:0}}],txInfo:{frequency:915000000,dr:5},adr:false,fCnt:0,fPort:1,data:dHN8MTYyNjk3OTc0OTgwNA==}",
				"{applicationID:5,applicationName:mestrado_simulacao,deviceName:DHT11,rxInfo:[{gatewayID:000000ffff001000,name:ExpGW,rssi:-57,loRaSNR:7,location:{latitude:0,longitude:0,altitude:0}}],txInfo:{frequency:915000000,dr:5},adr:false,fCnt:0,fPort:1,data:dHN8MTYyNjk3OTc0OTgwNA==}",
				"{applicationID:5,applicationName:mestrado_simulacao,deviceName:DHT11,devEUI:221597e4529df57d,rxInfo:[{name:ExpGW,rssi:-57,loRaSNR:7,location:{latitude:0,longitude:0,altitude:0}}],txInfo:{frequency:915000000,dr:5},adr:false,fCnt:0,fPort:1,data:dHN8MTYyNjk3OTc0OTgwNA==}",
				"{applicationID:5,applicationName:mestrado_simulacao,deviceName:DHT11,devEUI:221597e4529df57d,rxInfo:[{gatewayID:000000ffff001000,rssi:-57,loRaSNR:7,location:{latitude:0,longitude:0,altitude:0}}],txInfo:{frequency:915000000,dr:5},adr:false,fCnt:0,fPort:1,data:dHN8MTYyNjk3OTc0OTgwNA==}",
				"{applicationID:5,applicationName:mestrado_simulacao,deviceName:DHT11,devEUI:221597e4529df57d,rxInfo:[{gatewayID:000000ffff001000,name:ExpGW,rssi:-57,loRaSNR:7,location:{latitude:0,longitude:0,altitude:0}}],txInfo:{frequency:915000000,dr:5},adr:false,fCnt:0,fPort:1}",
				"2584.5 33 136\r\ng8k",
				"	2584.5 33 136g8k",
				"	2584.5 33\r\ng8k",
				"2584.5 33\r\ng8k",
				"2584.5 33g8k"};
		//https://www.codegrepper.com/code-examples/java/java+random+from+array
		Random r=new Random();     
		int randomNumber=r.nextInt(listaDeValoresInvalidos.length);
		payload = listaDeValoresInvalidos[randomNumber];
	
		return payload;
	}

}
