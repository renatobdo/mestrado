package controller;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
//https://hkotsubo.github.io/blog/2019-04-13/como-ler-e-manipular-um-json
import org.json.JSONObject;
import org.json.simple.parser.ParseException;
import org.eclipse.paho.client.mqttv3.*;

import com.mashape.unirest.http.HttpResponse;
import com.mashape.unirest.http.Unirest;

import controller.Filtro;
import model.IotAgent;

//import hivemq.mqtt.client.Publish;

import java.util.Base64;

/**
 * @author Dominik Obermaier
 * @author Christian Götz
 */
//============================Links uteis ===================================================//
//https://github.com/renatobdo/mestrado
//https://www.youtube.com/watch?v=mkx0CdWiPRA&t=46s
//https://medium.com/desenvolvendo-com-paixao/o-que-%C3%A9-solid-o-guia-completo-para-voc%C3%AA-entender-os-5-princ%C3%ADpios-da-poo-2b937b3fc530
//===========================================================================================//
public class Redirector implements IotAgent, MqttCallback {
	public int i = 0;
	public static long inicioParsing;
	public static long tempoParsing;
	public long tempoTotalParsing = 0;
	private String payload;
	private static char sense;
	private static String payloadFormatado;
	private static String mensagemTratada;
	private static String mensagemTratadaJson;
	private static String mensageIdentificada = "";
	private static String codigoDoStatus;
	public static String mensagem;

	private String data;
	private String topic;
	private String contentType;

	// private static String statusCode;

	public String getData() {
		SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy - HH:mm:ss aaa");
		Date hora = Calendar.getInstance().getTime(); // Ou qualquer outra forma que tem
		setData(sdf.format(hora));
		return this.data;
	}

	public void setData(String data) {
		this.data = data;
	}

	public void connectionLost(Throwable cause) {
		// This is called when the connection is lost. We could reconnect here.

	}

	public static String trataDados(String dado) {
		dado = dado.replaceAll("\"", "");
		// dado = dado.replaceAll(" ", "");
		return dado;
	}

	public static String trataDadosJson(String dado) {
		dado = dado.replace("}", ",\"ti\":\"json\"z");
		// dado = dado.replaceAll(" ", "");
		return dado;
	}

	public static String trataDadosJson2(String dado) {
		dado = dado.replace("z", "}");
		// dado = dado.replaceAll(" ", "");
		return dado;
	}

	public static String getMensagem() {
		return mensagem;
	}

	public static void setMensagem(String mensagem) {
		Redirector.mensagem = mensagem;
	}
	
	
	public static long getTempoParsing() {
		return tempoParsing;
	}

	public static void setTempoParsing(long tempoParsing) {
		Redirector.tempoParsing = tempoParsing;
	}

	public String analisaContentType(String message)
			throws MqttSecurityException, MqttException, InterruptedException, IOException, ParseException {

		int statusCode = 0;
		sense = 'n';
		//mensagem = message;
		setMensagem(message);
		payloadFormatado = getMensagem();
		System.out.println("MENSAGEM RECEBIDA DO BROKER ========== " + mensagem);
		// ============================Links uteis
		// ===================================================//
		// https://en.wikipedia.org/wiki/Verification-based_message-passing_algorithms_in_compressed_sensing
		// ============================Links uteis
		// ===================================================//
		if (getMensagem().contains("phyPayload")) {
			inicioParsing = System.currentTimeMillis();
			System.out.println("Contem phyPayload");
			mensageIdentificada = "5";

		} else

		// }else if(topic.contains("gateway")) {
		// System.out.println("Mensagem trocada entre o Loraapp ");
		// }else

		// 06/07/2021 if (mensagem.substring(1).contains("<")) {
		if (getMensagem().contains("<")) {
			// try {

			// faz o trabalho a ser medido

			if ((getMensagem().contains("<!DOCTYPE html>")) ||  (mensagem.contains("</div>"))
			// && (mensagem.contains(">")
			// && (mensagem.contains("</div>")
			// && (mensagem.contains("title"))
			// && (mensagem.substring(1).length()<64)
			)// ))
			{
				//Filtro f = new Filtro();
			//	String tipoDeFiltro = "temperatura";
				inicioParsing = System.currentTimeMillis();
			//	payloadFormatado = f.filtra("HTML", getMensagem(), tipoDeFiltro);
				payloadFormatado = getMensagem().substring(1);
				mensageIdentificada = "2";

				/*
				 * 30/08/2021 if (payloadFormatado.contains("INDEFINIDO")) { mensageIdentificada
				 * = "5"; // HTML payloadFormatado = payloadFormatado.substring(10);
				 * System.out.println("payloadFormatado HTML ==="+payloadFormatado);
				 * codigoDoStatus = redireciona("INDEFINIDO"); } else {
				 * 
				 * long tempoParsingHTML = (System.currentTimeMillis() - inicioParsing);
				 * System.out.println("Tempo de parsing HTML em milisegundos: " +
				 * tempoParsingHTML);
				 * 
				 * mensageIdentificada = "2"; // HTML codigoDoStatus = redireciona("HTML"); }
				 */
				// ============================Links uteis
				// ===================================================//
				// validador de xml ===== https://www.freeformatter.com/xml-validator-xsd.html
				// https://loiane.com/2009/03/documento-xml-bem-formado-introducao-ao-xml-parte-iv/
				// ===========================================================================================//
			} else if (getMensagem().contains(">") || (getMensagem().contains("<?xml version=\"1.0\" encoding=\"UTF-8\"?>"))
			// && ((mensagem.contains("measure device="))
			// && (mensagem.contains("key"))
			// && (mensagem.contains("t value"))
			// && (mensagem.contains(">"))
			// && ((mensagem.substring(1).length()<80))
			) {
				//Filtro f = new Filtro();
			//	String tipoDeFiltro = "temperatura";
				inicioParsing = System.currentTimeMillis();
			//	payloadFormatado = f.filtra("XML", getMensagem(), tipoDeFiltro);
				payloadFormatado = mensagem.substring(1);
				mensageIdentificada = "1"; // xml

			} else {
				inicioParsing = System.currentTimeMillis();
				mensageIdentificada = "5";

			}
			// }
			// } catch (Exception ex) {
			// System.out.println("Exce��o = "+ex);
			// }

		} else if (getMensagem().contains("t|")) {
			// System.out.println("tamanho da mensagem: "+mensagem.length()+" mensagem:
			// "+mensagem
			// +" tamanho da mensagem substring: "+mensagem.substring(1).length()
			// +" mensagem substring: "+mensagem.substring(1));

			// System.out.println("Tempo de parsing simples XML em milisegundos:
			// "+tempoParsingXML);

		//	Filtro f = new Filtro();
		//	String tipoDeFiltro = "temperatura";
			inicioParsing = System.currentTimeMillis();
		//	payloadFormatado = f.filtra("UL", getMensagem(), tipoDeFiltro);
			payloadFormatado = mensagem.substring(1);
			mensageIdentificada = "4"; // ul

			

		}

		else if ((getMensagem().contains("{"))) {
//Caso seja mensagem do tipo LoRa....Eu tenho que fazer esse if porque senão não consigo obter o JSON...
			if (getMensagem().contains("applicationID"))
			/*
			 * (mensagem.contains("applicationName")) && (mensagem.contains("deviceName"))
			 * && (mensagem.contains("devEUI")) && (mensagem.contains("gatewayID")) &&
			 * (mensagem.contains("name")) && (mensagem.contains("data")))
			 */ {
				// =============================================================================================
				// https://super.abril.com.br/blog/oraculo/como-se-definiu-o-numero-de-caracteres-de-um-tweet/
				// https://stackoverflow.com/questions/34522053/what-is-the-maximum-message-length-for-a-mqtt-broker
				// o máximo de caracteres que o protocolo MQTT transporta é 65536 bytes ou
				// 65,536Kbyte
				// Lembrando que cada caractere corresponde a 1 byte
				// =============================================================================================
				System.out.println("Tamanho da mensagem em bytes: " + getMensagem().length() + " bytes");
				mensageIdentificada = "6"; // LoRa
				// System.out.println("Tempo de parsing simples XML em milisegundos:
				// "+tempoParsingXML);
				inicioParsing = System.currentTimeMillis();
				payloadFormatado = mensagem;
				
		/*		if (getMensagem().charAt(0) == '6') {
					System.out.println("Mensagem vinda do Node-Red ou simulador Heliot");
					Filtro f = new Filtro();
					String tipoDeFiltro = "temperatura";
					inicioParsing = System.currentTimeMillis();
					payloadFormatado = f.filtra("LORA2", getMensagem().substring(1), tipoDeFiltro);
					// long tempoParsingUL = (System.currentTimeMillis() - inicioParsing);
					
					// codigoDoStatus = redireciona("LORA");
				
				}else {
					System.out.println("Mensagem vinda do Sense");
					sense = 's';

					Filtro f = new Filtro();
					String tipoDeFiltro = "temperatura";
					inicioParsing = System.currentTimeMillis();
					payloadFormatado = f.filtra("LORA", getMensagem(), tipoDeFiltro);
					// long tempoParsingUL = (System.currentTimeMillis() - inicioParsing);

					// codigoDoStatus = redireciona("LORA");
				}
*/	
				

				// ============================Links uteis
				// ===================================================//
				// http://www-db.deis.unibo.it/courses/TW/DOCS/w3schools/json/json_syntax.asp.html
				// https://jsonformatter.curiousconcept.com/#learn
				// https://jsonformatter.curiousconcept.com/#
				// ===========================================================================================//
				// Caso seja mensagem do tipo JSON
			} else if ((getMensagem().contains("}")) && (getMensagem().contains("\"t\":"))
			// mensagem.substring(1).length()<64 menor que 64 é uma estimativa para 4
			// atributos mais ou menos, ou seja,
			// o sensor irá enviar no máximo a temperatura, umidade, pressão? talvez até
			// menos dados...
			) {

				// System.out.println("Tempo de parsing completo JSON em milisegundos:
				// "+tempoParsingJSON);

			//	Filtro f = new Filtro();
			//	String tipoDeFiltro = "temperatura";
				inicioParsing = System.currentTimeMillis();
			//	payloadFormatado = f.filtra("JSON", getMensagem(), tipoDeFiltro);
				payloadFormatado = mensagem.substring(1);
				mensageIdentificada = "3"; // Json
				

				// String mensagemtratada = trataDados(mensagem);
				// int z = mensagem.substring(1).length();
				/*
				 * System.out.println("Content-type baseado em JSON"); //
				 * System.out.println("mensagem.substring(1) = " + z);
				 * System.out.println("mensagem JSON  ========== "+mensagem); String
				 * mensagemtratada = trataDadosJson(mensagem);
				 * System.out.println("mensagem JSON  tratada========== "+mensagemtratada);
				 * String mensagemtratada2 = trataDadosJson2(mensagemtratada);
				 * System.out.println("mensagem JSON  tratada2========== "+mensagemtratada2);
				 * mensagemTratadaJson = mensagem;
				 */

				// System.out.println("mensagem tratada 2 = " + mensagemtratada2);

			} else {
				// System.out.println("a casa caiu");
				// Aqui eu poderia colocar uma inteligência para que o sistema redirecione para
				// o IoT Agente mais próximo
				// Eu poderia formatar o dado que chega para o template que o IoT Agente
				// compreende.
				inicioParsing = System.currentTimeMillis();
				mensageIdentificada = "5";
				
			}

		}else {
			String[] payloadSplit = getMensagem().split(" ");

			// Mensagem ASCII do sensor TEROS 12 contém 3 parâmetros separados por espaços
			// https://pt.stackoverflow.com/questions/70679/pegar-valores-separados-por-espa%C3%A7os-em-java
			if ((payloadSplit.length == 3)  &&  (getMensagem().contains("\t")) &&  (getMensagem().contains("\r\n"))) {
				Filtro f = new Filtro();
				String tipoDeFiltro = "temperatura";
				inicioParsing = System.currentTimeMillis();
				payloadFormatado = f.filtra("TEROS12", getMensagem(), tipoDeFiltro);
				mensageIdentificada = "7"; 
			
			} else {
				inicioParsing = System.currentTimeMillis();
				mensageIdentificada = "5";
			}
			
		} 
		
		System.out.println("Logs ======== ");
		System.out.println("payloadFormatado = "+payloadFormatado);

		if (payloadFormatado.contains("INDEFINIDO")) {
			
			payloadFormatado = payloadFormatado.substring(10);
			System.out.println("payloadFormatado INDEFINIDO === " + payloadFormatado);
			codigoDoStatus = redireciona("INDEFINIDO");
			
		} else if (mensageIdentificada.equals("1")) {
			
			//long tempoParsingXML = (System.currentTimeMillis() - inicioParsing);
			tempoParsing = (System.currentTimeMillis() - inicioParsing);
			System.out.println("Tempo de parsing XML em milisegundos: " + tempoParsing);
			codigoDoStatus = redireciona("XML");
			
		} else if (mensageIdentificada.equals("2")) {
			
			//long tempoParsingHTML = (System.currentTimeMillis() - inicioParsing);
			tempoParsing = (System.currentTimeMillis() - inicioParsing);
			System.out.println("Tempo de parsing HTML em milisegundos: " + tempoParsing);
			codigoDoStatus = redireciona("HTML");
			
		} else if (mensageIdentificada.equals("3")) {
			
			//long tempoParsingJSON = (System.currentTimeMillis() - inicioParsing);
			tempoParsing = (System.currentTimeMillis() - inicioParsing);
			System.out.println("Tempo de parsing JSON em milisegundos: " + tempoParsing);
			codigoDoStatus = redireciona("JSON");
			
		} else if (mensageIdentificada.equals("4") || (mensageIdentificada.equals("7")))
		 {

			//long tempoParsingUL = (System.currentTimeMillis() - inicioParsing);
			tempoParsing = (System.currentTimeMillis() - inicioParsing);
			System.out.println("Tempo de parsing UL em milisegundos: " + tempoParsing);
			codigoDoStatus = redireciona("UL");

		} else if (mensageIdentificada.equals("5")) {
			
			//long tempoParsingIndefinido = (System.currentTimeMillis() - inicioParsing);
			tempoParsing = (System.currentTimeMillis() - inicioParsing);
			System.out.println("Tempo de parsing INDEFINIDO em milisegundos: " + tempoParsing);
			System.out.println("Payload INDEFINIDO antes de redireciona-lo ======" + mensagem);
			codigoDoStatus = redireciona("INDEFINIDO");

		} else if (mensageIdentificada.equals("6")) {
			
			//long tempoParsingLora = (System.currentTimeMillis() - inicioParsing);
			tempoParsing = (System.currentTimeMillis() - inicioParsing);
			System.out.println("Tempo de parsing LoRa Sense em milisegundos: " + tempoParsing);
			//System.out.println("Tempo de parsing LoRa Sense em milisegundos: " + tempoParsingLora);
			//long tempoParsingLora2 = (System.currentTimeMillis() - inicioParsing);
			//System.out.println("Tempo de parsing LoRa Heliot/Node-Red em milisegundos: " + tempoParsingLora2);
			codigoDoStatus = redireciona("LORA");
		}

		this.logs(payloadFormatado, mensageIdentificada, codigoDoStatus, tempoParsing);
		return payloadFormatado;

	}

	public String redireciona(String contentType) throws MqttSecurityException, MqttException {
		this.contentType = contentType;
		int statusCode;
		if (contentType.equals("XML")) {
			try {
				//Unirest.setTimeouts(0, 0);
				HttpResponse<String> response = Unirest.post(url_iotagent_xml).header("Content-Type", "application/xml")
						.body(payloadFormatado).asString();
				// System.out.println(mensagem.substring(1) + "<ti value = \"XMS\"
				// /></measure>");
				System.out.println("response XML = " + response.getStatus());
				statusCode = response.getStatus();
				codigoDoStatus = Integer.toString(statusCode);
				System.out.println("Mensagem XML que FOI REDIRECIONADA =======" + payloadFormatado);
			} catch (Exception e) {
				System.out.println("Algo deu errado! erro = " + e.getMessage());

				System.out.println("Causa do erro " + e.getCause());
			} finally {

				System.out.println("O 'try catch' do tratamento XML finalizou com status code = " + codigoDoStatus);
			}

		} else if (contentType.equals("HTML")) {
			System.out.println("=======================================================");
			System.out.println("Nao conheco IoT Agent que trata dados do tipo HTML...");
			System.out.println("=======================================================");
			codigoDoStatus = "404";
		} else if (contentType.equals("JSON")) {
			try {
				//Unirest.setTimeouts(0, 0);
				HttpResponse<String> response = Unirest
						// 34.95.206.212
						// 35.247.252.230
						.post(url_iotagent_json).header("Content-Type", "application/json")

						// .body(mensagemTratadaJson).asString();
						.body(payloadFormatado).asString();
				System.out.println("response JSON = " + response.getStatus());
				statusCode = response.getStatus();
				codigoDoStatus = Integer.toString(statusCode);
				System.out.println("Mensagem JSON que FOI REDIRECIONADA =======" + payloadFormatado);
			} catch (Exception e) {
				System.out.println("Algo deu errado! erro = " + e.getMessage());
				// System.out.println("response JSON = " + response.getStatus());
				System.out.println("Causa do erro " + e.getCause());
			} finally {
				System.out.println("O 'try catch' do tratamento JSON finalizou.");
			}
		} else if ((contentType.equals("UL")) || (contentType.equals("TEROS12")) ) {
			try {
				Unirest.setTimeouts(0, 0);
				HttpResponse<String> response = Unirest

						// 35.247.252.230:7896//
						.post(url_iotagent_ul)
						// .post("http://192.168.99.100:7896/iot/d?k=4jggokgpepnvsb2uv4s40d59ov&i=temp002")
						// .post("http://192.168.99.100:7896/iot/d?k=4jggokgpepnvsb2uv4s40d59ov&i=dht22")
						.header("Content-Type", "text/plain").body(payloadFormatado).asString();
				System.out.println("response = " + response.getStatus());
				statusCode = response.getStatus();
				codigoDoStatus = Integer.toString(statusCode);
				System.out.println("Mensagem que FOI REDIRECIONADA =======" + payloadFormatado);
			} catch (Exception e) {
				System.out.println("Algo deu errado! erro = " + e.getMessage());
				// System.out.println("response JSON = " + response.getStatus());
				System.out.println("Causa do erro " + e.getCause());
			} finally {
				System.out.println("O 'try catch' do tratamento UL finalizou com status code = " + codigoDoStatus);
			}
		} else if (contentType.equals("INDEFINIDO")) {
			mensageIdentificada = "5"; // Aleatorio
			statusCode = 400;
			codigoDoStatus = Integer.toString(statusCode);
			System.out.println(
					"Protocolo nao identificado, mal formado ou invalido. Nao foi possivel realizar o redirecionamento");
			System.out.println("=======================================================");
			System.out.println(
					"Nao conheco IoT Agent que trata dados desse tipo mas pelo payload que recebi acredito que você queria enviar para o IoT Agent ......");
			System.out.println("=======================================================");
		} else if (contentType.equals("LORA")) {
			MqttClient mqttClient = new MqttClient(ipBrokerMqtt, String.valueOf(System.nanoTime()));
			// System.out.println("mqttClient = "+mqttClient);
			MqttConnectOptions connOpts = new MqttConnectOptions();
			// System.out.println("1==============connOpts = "+connOpts);
			MqttMessage messagelora = new MqttMessage();

			byte[] mensagemEmByte = payloadFormatado.getBytes();

			messagelora.setPayload(mensagemEmByte);

			System.out.println("Mensagem que sera publicada no topico " + messagelora.toString());
			// System.out.println("connOpts = "+connOpts);
			// MqttTopic topic2 =
			// mqttClient.getTopic("application/5/device/221597e4529df57d/rx");
			MqttTopic topic3 = mqttClient.getTopic(topic);
			mqttClient.connect(connOpts);
			// System.out.println("T�pico = "+topic2);
			System.out.println("Topico3 Node-Redeeeeeeee  = " + topic3);
			topic3.publish(messagelora);
			// 308 = permanent redirect
			// https://httpstatuses.com/
			codigoDoStatus = "308";
			System.out.println("Status CODE LORA ================ " + codigoDoStatus);

		} else {
			System.out.println("Não redireciono protocolo INDEFINIDO...");
		}

		return codigoDoStatus;
	}

	public void logs(String payload, String mensageIdentificada, String codigoDoStatus, long tempoParsing1) {
		String mensagem = payload;
		// 06/07/2021if ((mensagem.substring(1).contains("phyPayload") || (Sense ==
		// 's'))) {
		setTempoParsing(tempoParsing1);
		System.out.println("Logs payload = " + mensagem);
		System.out.println("Logs mensagem identificada = " + mensageIdentificada);
		System.out.println("Logs codigoDoStatus  = " + codigoDoStatus);
		System.out.println("mensagem que chegou ao método logs ===== " + mensagem);
		// if ((mensagem.contains("phyPayload") || (sense == 's'))) {
		mensagemTratada = trataDados(mensagem);
		System.out.println("mensagem tratada para persistencia local pelo método logs = " + mensagemTratada);

		// } else {

		// https://www.alura.com.br/artigos/trocando-caracteres-de-uma-string-no-java#:~:text=Precisamos%20sumir%20com%20os%20caracteres,que%20passarmos%20por%20outro%20caractere.
		// mensagemTratada = trataDados(mensagem.substring(1));
		// mensagemTratada = trataDados(mensagem);
		// mensagemTratada = mensagem;
		// System.out.println("mensagem tratada para persistencia local = " +
		// mensagemTratada);

		// }
		if (mensagemTratada.substring(0, 1).equals("5")){
			mensagemTratada = mensagemTratada.substring(1);
		
		}

		System.out.println("{\r\n" + "\"contentype\":\"" + mensageIdentificada + "\",\r\n    " + " \"statusCode\":\""
				+ codigoDoStatus + "\"payload\":\"" + mensagemTratada + "\",\r\n    " + "\"description\":\" data: "
				+ this.getData() + " \"\r\n  \"tempoParsing\": \""+getTempoParsing()+"\"}");
		// int contador = contador + 1;
		System.out.println("getTempoParsing ==== "+getTempoParsing());
		
		try {

			Unirest.setTimeouts(0, 0);
			HttpResponse<String> response2 = Unirest.post(url_local).header("Content-Type", "application/json") //
					.body("{\r\n    \"contentype\":\"" + mensageIdentificada + "\",\r\n    \"statusCode\":\""
							+ codigoDoStatus + "\",\r\n    \"payload\":\"" + mensagemTratada
							+ "\",\r\n    \"description\":\"data:" + this.getData() + "\",\r\n      \"tempoParsing\": \""+getTempoParsing()+"\"\r\n}")
					.asString();
			codigoDoStatus = Integer.toString(response2.getStatus());
			System.out.println("Resultado da persistência Local = " + codigoDoStatus);
		} catch (Exception e) {
			System.out.println("Algo deu errado! erro = " + e.getMessage());
		} finally {
			System.out.println("O 'try catch' do tratamento de dados local finalizou.");
		}
	}

	public void deliveryComplete(IMqttDeliveryToken token) {
		// no-op
		System.out.println(token);
	}

	@Override
	public void messageArrived(String topic, MqttMessage mqttMessage) throws Exception {
		this.topic = topic;
		this.payload = mqttMessage.toString();

		Unirest.setTimeouts(0, 0);
		//https://www.baeldung.com/unirest
		//Unirest.setConcurrency(5000, 5000);
		
		System.out.println(
				"Mensagem chegando ao topico: " + topic + " - Data: " + this.getData() + "  Message: " + this.payload);

		// String mensagem = this.payload;
		inicioParsing = System.currentTimeMillis();
		System.out.println("Inicio do analisaContentType = " + inicioParsing);
		System.out.println("Resultado de analisaContentType = " + this.analisaContentType(this.payload));
		// this.redireciona(this.payload);

		// https://www.epochconverter.com/
		long tempoExecucaoFinal = (System.currentTimeMillis() - inicioParsing);
		System.out.println("Tempo de execucao  do analisaContentType em milisegundos: " + tempoExecucaoFinal);

		// tempoTotalParsing = tempoTotalParsing + tempoParsingFinal;
		// System.out.println("Tempo total do parsing: "+tempoTotalParsing);

		System.out.println("Status Code = " + codigoDoStatus);

	}

}
