package controller;

import java.io.IOException;
import java.io.StringReader;
import java.math.RoundingMode;
import java.sql.Timestamp;
import java.text.DecimalFormat;
import java.util.Base64;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.json.JSONException;
import org.json.JSONObject;
import org.json.simple.parser.ParseException;
import org.jsoup.Jsoup;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import model.SensorTeros;
import model.Relatorio;
import model.SensorHTML;
import model.SensorJSON;
import model.SensorLora;
import model.SensorUL;
import model.SensorXML;
import model.Template;

public class Filtro {

	private float temperatura;
	private String protocolo;
	private static String payload;
	private static String tipoDeFiltro;
	private static float parametro;

	public float getTemperatura() {
		return temperatura;
	}

	public void setTemperatura(double d) {
		this.temperatura = (float) d;
	}

	public String getProtocolo() {
		return protocolo;
	}

	public void setProtocolo(String protocolo) {
		this.protocolo = protocolo;
	}

	public String getPayload() {
		return payload;
	}

	public void setPayload(String payload1) {
		payload = payload1;
	}

	private static Document convertStringToXMLDocument(String xmlString) {
		// Parser that produces DOM object trees from XML content
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();

		// API to obtain DOM Document instance
		DocumentBuilder builder = null;
		try {
			// Create DocumentBuilder with default configuration
			builder = factory.newDocumentBuilder();

			// Parse the content to Document object
			Document doc = builder.parse(new InputSource(new StringReader(xmlString)));
			return doc;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	// ======================================================================================
	// https://howtodoinjava.com/java/xml/parse-string-to-xml-dom/
	// https://mkyong.com/java/how-to-read-xml-file-in-java-dom-parser/
	// ======================================================================================
	public float parseXML() {
		System.out.println("Payload TODO ==================== " + payload);
		Document doc = convertStringToXMLDocument(payload.substring(1));
		System.out.println("Payload SUBSTRING(1) ==================== " + payload.substring(1));
		// Verify XML document is build correctly
		System.out.println("Root Element :" + doc.getDocumentElement().getNodeName());
		System.out.println("------");
		System.out.println(doc.getFirstChild().getNodeName());

		Element element = doc.getDocumentElement();
		NodeList nodeList = element.getElementsByTagName("t");
		if (nodeList.getLength() > 0) {
			Element elementAttribute = (Element) nodeList.item(0);
			String temperatura = elementAttribute.getAttribute("value");
			if (!"".equals(temperatura)) {
				float result = Float.parseFloat(temperatura);
				// System.out.println(!"".equals(temperatura));
				System.out.println("temperatura " + result);
				return result;
			} else {
				System.out.println("temperatura esta vazia ...");
			}
		}
		return temperatura;

	}

	// ========================================================================================
	// https://jsoup.org/cookbook/extracting-data/dom-navigation
	// ========================================================================================
	public float parseHTML() {
		org.jsoup.nodes.Document document = Jsoup.parse(payload);
		org.jsoup.nodes.Element tempHTML = document.getElementById("temperature");
		System.out.println("temperature ===================================================" + tempHTML.text());
		String tempHTML2 = tempHTML.text();
		float tempHTML3 = Float.parseFloat(tempHTML2);
		return tempHTML3;

	}

	private float parseUL() {
		String[] payloadSplit = payload.split("\\|");

		for (int i = 0; i < payloadSplit.length; i++) {
			// System.out.println("payloadSplit["+i+"] = "+payloadSplit[i]);
			if (payloadSplit[i].contentEquals("4t")) {
				// System.out.println("CONTÉM T aeeeee ");
				parametro = Float.parseFloat(payloadSplit[i + 1]);
			}
		}
		float tempUL = parametro;
		/*
		 * System.out.println("t =========== "+payloadSplit[0]);
		 * System.out.println("TEMPERATURA =========== "+payloadSplit[1]);
		 * System.out.println("TI =========== "+payloadSplit[2]);
		 * System.out.println("UL =========== "+payloadSplit[3]);
		 */

		return tempUL;
	}

	private float parseTerosAscII() {
		String[] payloadSplit = payload.split(" ");

		float tempTeros = Float.parseFloat(payloadSplit[1]);
		return tempTeros;
	}

	private float parseTerosHex() {
		String[] payloadSplit = payload.split(" ");
		StringBuilder payloadHexadecimalSemEspacos = new StringBuilder("");
		for (int i = 0; i < payloadSplit.length; i++) {
			payloadHexadecimalSemEspacos.append(payloadSplit[i]);
		}
		// https://www.tutorialspoint.com/converting-a-stringbuilder-to-string-in-java
		// 0009323538332E382032342E38203133350D673A6B0D0A0009323538342E352032342E38203133360D6739580D0A00
		String payloadHexadecimalSemEspacos2 = payloadHexadecimalSemEspacos.toString();
		String payloadHexParaAscII = hexToAscii(payloadHexadecimalSemEspacos2);
		String[] payloadSplit2 = payloadHexParaAscII.split(" ");
		//System.out.println("testes = " + payloadJunto2.substring(4, 34));
		//System.out.println("Payload junto = " + payloadJunto2);
		//float tempTeros = Float.parseFloat(hexToAscii(payloadJunto2.substring(4, 34)));
		float tempTeros = Float.parseFloat(payloadSplit2[1]);
		//System.out.println("Resultado1 = " + Float.parseFloat(hexToAscii(payloadJunto2)));
		
		System.out.println("Resultado payload em Hexadecimal convertido para ASCII - TEROS = " + tempTeros);
		
		return tempTeros;
	}
	//https://www.baeldung.com/java-convert-hex-to-ascii
	private static String hexToAscii(String hexStr) {
	    StringBuilder output = new StringBuilder("");
	    
	    for (int i = 0; i < hexStr.length(); i += 2) {
	    //	System.out.println("i = "+i+" i += 2 = "+(i+=2));
	        String str = hexStr.substring(i, i + 2);
	    //    System.out.println("string = "+str);
	        output.append((char) Integer.parseInt(str, 16));
	    }
	    
	    return output.toString();
	}

	// ===========================================================================================
	// https://stackoverflow.com/questions/11874919/parsing-json-string-in-java
	// ==========================================================================================
	private float parseJSON() throws ParseException, JSONException {
		// String[] payloadSplit = payload.split("\"");
		// float tempJSON = Float.parseFloat(payloadSplit[3]);

		org.json.JSONObject obj = new org.json.JSONObject(payload.substring(1));
		String tempJSON = obj.getString("t");
		System.out.println("TEMPERATURA JSON =============== " + tempJSON);
		setTemperatura(Float.parseFloat(tempJSON));

		return this.getTemperatura();
	}

	private String parseLoraSense() {
		/*
		 * String[] payloadSplit = payload.split("\""); for (int i = 0 ;
		 * payloadSplit.length > i; i++) {
		 * System.out.println("payloadSplit["+i+"] = "+payloadSplit[i]); } return 21;
		 */
		JSONObject obj = new JSONObject(payload);
		String pegaData = obj.getString("data");
		String pegaDataString = pegaData.toString();
		System.out.println("o campo data é: " + pegaData);

		String campoDataDesserializado = new String(Base64.getDecoder().decode(pegaDataString));
		System.out.println("Campo data que sera feito o POST = " + campoDataDesserializado + "|ti|lora");

		String campoDataTratado = campoDataDesserializado + "|ti|lora";
		String campoDataConvertidoBase64 = Base64.getEncoder().encodeToString(campoDataTratado.getBytes());
		String payloadComCampoDataConvertidoBase64 = payload.replace(pegaDataString, campoDataConvertidoBase64);
		System.out.println("Payload com campo data convertido para base64 ==== " + payloadComCampoDataConvertidoBase64);
		return payloadComCampoDataConvertidoBase64;
	}

	private float parseLoraSimuladorHeliot() {
		/*
		 * String[] payloadSplit = payload.split("\""); for (int i = 0 ;
		 * payloadSplit.length > i; i++) {
		 * System.out.println("payloadSplit["+i+"] = "+payloadSplit[i]); } return 21;
		 */

		JSONObject obj = new JSONObject(payload);
		String pegaData = obj.getString("data");
		String pegaDataString = pegaData.toString();
		System.out.println("o campo data é: " + pegaData);
		String campoDataDesserializado = new String(Base64.getDecoder().decode(pegaDataString));
		System.out.println("Campo data que sera feito o POST = " + campoDataDesserializado);
		String[] payloadSplit = campoDataDesserializado.split("\\|");
		System.out.println("payloadSplit[1] Deveria vir a temperatura == " + payloadSplit[1]);
		// https://mkyong.com/java/how-to-get-current-timestamps-in-java/
		// Timestamp timestamp = new Timestamp(System.currentTimeMillis());
		// System.out.println(timestamp.getTime());

		float tempLora = Float.parseFloat(payloadSplit[1]);

		// ==========================================
		// https://stackoverflow.com/questions/153724/how-to-round-a-number-to-n-decimal-places-in-java
		// ============================================
		DecimalFormat df = new DecimalFormat("#");
		df.setRoundingMode(RoundingMode.FLOOR);
		// System.out.println("testes === \"05091981000\"+"+df.format(tempLora));
		// return Float.parseFloat("19810509111"+df.format(tempLora));
		return Float.parseFloat(df.format(tempLora));
		// return (float)timestamp.getTime();

	}

	public String filtra(String protocolo, String payload1, String filtro)
			throws InterruptedException, IOException, ParseException {
		int i = 1;
		setProtocolo(protocolo);
		tipoDeFiltro = filtro;
		payload = payload1;
		// ============================Links uteis
		// ===================================================//
		// https://stackoverflow.com/questions/4950966/a-better-way-to-run-code-for-a-period-of-time
		// https://www.baeldung.com/spring-webflux-concurrency
		// https://www.devmedia.com.br/threads-paralelizando-tarefas-com-os-diferentes-recursos-do-java/34309
		// ============================Links uteis
		// ===================================================//
		System.out.println("Filtro número = " + i);

		if ((getProtocolo().equals("XML"))) {
			// caso seja XML

			String nameSensorXML = "sensorXML_DHT11_" + i;
			SensorXML sensorXML = new SensorXML(i, nameSensorXML);
			System.out.println("Nome do sensor = " + sensorXML.getName());
			Relatorio.setTipo(1);
			System.out.println("Contagem de sensores XML = " + Relatorio.contabiliza());
			// tempo de parsing...
			/*
			 * 24/08/2021 if (tipoDeFiltro.equals("temperatura")) { float tempXML =
			 * sensorXML.getTemperatura(); System.out.println("temperatura do XML ======== "
			 * + tempXML); // fim parsing... System.out.println("payload formatado= " +
			 * this.formataPayload(this.protocolo, tempXML)); // System.out.println("XML = "
			 * + protocolo);
			 * 
			 * return this.formataPayload(this.protocolo, tempXML); } else {
			 * System.out.println("Payload completo ===================" +
			 * sensorXML.fornecerPayload()); // tempo pra formatar o payload...
			 * 
			 * }
			 */
			/*
			 * String[] payloadSplit = payload.split("\"");
			 * System.out.println("nome do device =========== "+payloadSplit[5]);
			 * System.out.println("key =========== "+payloadSplit[7]);
			 * System.out.println("TEMPERATURA =========== "+payloadSplit[9]);
			 */
			Template templateXML = new Template();
			Float tempXML = parseXML();
			// return payload =
			// templateXML.formataPayload(this.protocolo,Float.parseFloat(payloadSplit[9]));
			return payload = templateXML.formataPayload(getProtocolo(), tempXML);
			// ou poderia fazer o que está abaixo, mas o certo não seria pegar o dado direto
			// do sensor já que o dado deve ser coletado do broker...
			// return payload =
			// templateXML.formataPayload(this.protocolo,sensorXML.getTemperatura());

			// Caso seja HTML
		} else if (getProtocolo().equals("HTML")) {
			if (!payload.contains("°")) {
				// filtro mais detalhado para pegar outras inconsistencias como por exemplo
				// uma div sem id = temperatura...

				String nameSensorHTML = "sensorHTML_DHT11_" + i;
				SensorHTML sensorHTML = new SensorHTML(i, nameSensorHTML);
				System.out.println("nome do sensor = " + sensorHTML.getName());
				Relatorio.setTipo(2);
				System.out.println("Contagem de sensores HTML = " + Relatorio.contabiliza());

				Template templateHTML = new Template();

				// =================================================================================
				// https://www.oracle.com/corporate/features/jsoup-html-parsing-library.html
				// =================================================================================
				float tempHTML = parseHTML();

				System.out.println("Temperatura = " + tempHTML);
				return payload = templateHTML.formataPayload(getProtocolo(), tempHTML);
			} else {
				// poderia colocar um contador para verificar o quanto esse segundo filtro é
				// importante...
				// colocaria um contador indicando que o segundo filtro contou xxx dados...
				this.setProtocolo("INDEFINIDO");

				int tempIndefinido = i;
				// System.out.println("Temperatura = " + tempIndefinido);

				// fim parsing...
				// Poderia fazer um filtro INTELIGENTE AQUI...
				// System.out.println("payload formatado= " +
				// this.formataPayload(this.protocolo, tempIndefinido));

			}
			// Caso seja JSON
		} else if (getProtocolo().equals("JSON")) {

			String nameSensorJSON = "sensorJSON_DHT11_" + i;
			SensorJSON sensorJSON = new SensorJSON(i, nameSensorJSON);
			System.out.println("nome do sensor = " + sensorJSON.getName());
			Relatorio.setTipo(3);
			System.out.println("Contagem de sensores JSON = " + Relatorio.contabiliza());
			// tempo de parsing...

			Template templateJSON = new Template();

			// =================================================================================
			// https://www.oracle.com/corporate/features/jsoup-html-parsing-library.html
			// =================================================================================
			float tempJSON = parseJSON();

			System.out.println("Temperatura = " + tempJSON);
			// fim parsing...
			System.out.println(
					"payload formatado aeeeeeeeeeeeeeeeeeee= " + this.formataPayload(getProtocolo(), tempJSON));
			// System.out.println("HTML = " + protocolo);
			return payload = templateJSON.formataPayload(getProtocolo(), tempJSON);

			// Caso seja UL
		} else if (getProtocolo().equals("UL")) {
			if ((payload.substring(1).length() >= 3) && (payload.substring(1).length() <= 280)) {
				String nameSensorUL = "sensorUL_DHT11_" + i;
				SensorUL sensorUL = new SensorUL(i, nameSensorUL);
				System.out.println("nome do sensor = " + sensorUL.getName());
				Relatorio.setTipo(4);
				System.out.println("Contagem de sensores UL = " + Relatorio.contabiliza());
				// tempo de parsing...

				Template templateUL = new Template();

				float tempUL = parseUL();

				// fim parsing...
				System.out.println("payload formatado= " + this.formataPayload(getProtocolo(), tempUL));
				// System.out.println("HTML = " + protocolo);
				return payload = templateUL.formataPayload(getProtocolo(), tempUL);
			} else {
				// poderia colocar um contador para verificar o quanto esse segundo filtro é
				// importante...
				// colocaria um contador indicando que o segundo filtro contou xxx dados...
				this.setProtocolo("INDEFINIDO");
				int tempIndefinido = i;
				// System.out.println("Temperatura = " + tempIndefinido);

				// fim parsing...
				// Poderia fazer um filtro INTELIGENTE AQUI...
				// System.out.println("payload formatado= " +
				// this.formataPayload(this.protocolo, tempIndefinido));

			}
			// Caso seja Aleatório
		} else if ((getProtocolo().equals("LORA")) || (getProtocolo().equals("LORA2"))) {

			String nameSensorLora = "sensorLora_DHT11_" + i;
			SensorLora sensorLora = new SensorLora(i, nameSensorLora);
			System.out.println("nome do sensor = " + sensorLora.getName());
			Relatorio.setTipo(6);
			System.out.println("Contagem de sensores LoRa = " + Relatorio.contabiliza());

			if (getProtocolo().equals("LORA2")) {
				System.out.println("mensagem vinda do Heliot.... ");
				Template templateLora = new Template();

				float tempLora = parseLoraSimuladorHeliot();

				return payload = templateLora.formataPayload(getProtocolo(), tempLora);
			} else {
				System.out.println("mensagem vinda do Sense.... ");
				return payload = parseLoraSense();
				
			}

		}else if (getProtocolo().equals("TEROS12")) {
			String nameSensorTeros = "sensorTEROS12_" + i;
			SensorTeros sensorTerosA = new SensorTeros(i, nameSensorTeros);
			System.out.println("nome do sensor = " + sensorTerosA.getName());
			Relatorio.setTipo(7);
			System.out.println("Contagem de sensores Teros = " + Relatorio.contabiliza());
			// tempo de parsing...

			Template templateTeros = new Template();

			float tempTeros = parseTerosAscII();

			// fim parsing...
			System.out.println("payload formatado Teros = " + this.formataPayload(getProtocolo(), tempTeros));
			// System.out.println("HTML = " + protocolo);
			return payload = templateTeros.formataPayload(getProtocolo(), tempTeros);
		
		}else {
			setProtocolo("INDEFINIDO");
		}

		if (getProtocolo().equals("INDEFINIDO")) {

			System.out.println("payload INVÁLIDO NÃO formatado ou FILTRADO = " + payload);
			Relatorio.setTipo(5);
			System.out.println("Contagem de sensores INDEFINIDOS = " + Relatorio.contabiliza());
			System.out.println(
					"this.getProtocolo()+payload ==================================" + getProtocolo() + payload);
			return getProtocolo() + payload;
		}
		i++;
		// System.out.println("contador = "+i++);
		// Aqui eu coloco de quanto em quanto tempo sera realizada a requisicao.
		// Nesse caso a cada 3segundos ira fazer a requisicao.
		// Thread.sleep(2000);
		// Relatorio.mostraRelatorio();
		return payload;
	}

	private String converteBase64(String loraData) {

		return Base64.getEncoder().encodeToString(loraData.getBytes());

	}

	public String formataPayload(String protocolo, float temperatura) throws IOException {
		String payload = "";
		setProtocolo(protocolo);
		
		if (getProtocolo().equals("XML")) {

			payload = "<measure device=\"dht22\" key=\"4jggokgpepnvsb2uv4s40d59ov\"><t value=\"" + temperatura + "\" />"
					+ "<ti value = \"XML\" /></measure>";
			// System.out.println("payload = "+payload);
		} else if (getProtocolo().equals("HTML")) {

			payload = "<!DOCTYPE html><div id=\"temperature\">" + temperatura + "</div><div id=\"ti\">HTML</div>";
		} else if (getProtocolo().equals("JSON")) {

			payload = "{\"t\":" + "\"" + temperatura + "\",\"ti\":\"JSON\"}"; // +"\""+ ", \"ti\": \"JSON\"}";
		} else if (getProtocolo().equals("UL")) {

			payload = "t|" + temperatura + "|ti|UL";
			
		} else if (getProtocolo().equals("TEROS12")) {
			
			payload = "t|" + temperatura + "|ti|TEROS12";
			
		}else if (getProtocolo().equals("INDEFINIDO")) {

			// int id = (int) (this.temperatura);
			// String nameSensorIndefinido = "sensorIndefinido_" + id;
			// SensorIndefinido sensorIndefinido = new SensorIndefinido(id,
			// nameSensorIndefinido);

			// payload = sensorIndefinido.fornecerPayload();
			// payload = sensorIndefinido.fornecerPayload();
			System.out.println("Sensor INDEFINIDO.....");
		} else if (getProtocolo().equals("LORA")) {

			String loraData = "ts|" + String.valueOf(this.temperatura) + "|ti|lora";
			String textoSerializado = converteBase64(loraData);
			payload = "{\"applicationID\":\"5\",\"applicationName\":\"mestrado_simulacao\",\"deviceName\":\"DHT11\",\"devEUI\":\"221597e4529df57d\","
					+ "\"rxInfo\":[{\"gatewayID\":\"000000ffff001000\",\"name\":\"ExpGW\",\"rssi\":-57,\"loRaSNR\":7,\"location\":{"
					+ "\"latitude\":0,\"longitude\":0,\"altitude\":0}}],\"txInfo\":{\"frequency\":915000000,\"dr\":5},\"adr\":false,"
					+ "\"fCnt\":0,\"fPort\":1,\"data\":\"" + textoSerializado + "\"}";
		}
		return payload;
	}

}
