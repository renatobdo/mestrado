package view;

import java.io.IOException;
import java.util.Base64;
import java.util.Random;

import org.eclipse.paho.client.mqttv3.MqttException;

import controller.Publisher;
import controller.Subscriber;
import model.Relatorio;
import model.SensorHTML;
import model.SensorIndefinido;
import model.SensorJSON;
import model.SensorLora;
import model.SensorTeros;
import model.SensorUL;
import model.SensorXML;
import model.Template;

public class Simulador {
	int qtdSensores;
	int periodicidade;
	int duracao;
	private static String protocolo;
	private float temperatura;
	private static String tipoDeSimulador;
	private static String payload;
	private static float tempXML;
	private static float tempHTML;
	private static float tempJSON;
	private static float tempUL;
	private static float tempLora;
	private static float tempTeros;
	private static int i;

	public Simulador(int qtdSensores, int periodicidade, int duracao) throws IOException {
		super();
		this.qtdSensores = qtdSensores;
		this.periodicidade = periodicidade;
		this.duracao = duracao;

		SensorXML sensorXML = new SensorXML(0, "SensorXML_Inicial");
		System.out.println("Nome do sensor = " + sensorXML.getName());
		setTempXML(sensorXML.getTemperatura());
		System.out.println("temperatura do XML ======== " + getTempXML());

		SensorHTML sensorHTML = new SensorHTML(0, "SensorHTML_Inicial");
		System.out.println("nome do sensor = " + sensorHTML.getName());
		setTempHTML(sensorHTML.getTemperatura());
		System.out.println("temperatura do HTML ======== " + getTempHTML());

		SensorJSON sensorJSON = new SensorJSON(0, "sensorJSON_Inicial");
		System.out.println("nome do sensor = " + sensorJSON.getName());
		setTempJSON(sensorJSON.getTemperatura());
		System.out.println("temperatura do HTML ======== " + getTempJSON());

		SensorUL sensorUL = new SensorUL(0, "SensorUL_Inicial");
		System.out.println("nome do sensor = " + sensorUL.getName());
		setTempUL(sensorUL.getTemperatura());
		System.out.println("temperatura do UL ======== " + getTempUL());

		SensorIndefinido sensorIndefinido = new SensorIndefinido(0, "SensorIndefinido_Inicial");
		SensorLora sensorLora = new SensorLora(0, "SensorLora_Inicial");
		setTempLora(sensorLora.getTemperatura());
		System.out.println("temperatura do LoRa ======== " + getTempLora());

		SensorTeros sensorTeros12 = new SensorTeros(0, "SensorTeros_inicial");
		System.out.println("nome do sensor = " + sensorTeros12.getName());
//		System.out.println("payload completo TEROS12 = " + sensorTeros12.fornecerPayload());
		setTempTeros(sensorTeros12.getTemperatura());
		System.out.println("temperatura do Teros12 ======== " + getTempTeros());
		i = 1;

	}

	public static String getTipoDeSimulador() {
		return tipoDeSimulador;
	}

	public static void setTipoDeSimulador(String tipoDeSimulador) {
		Simulador.tipoDeSimulador = tipoDeSimulador;
	}

	public static String getPayload() {
		return payload;
	}

	public static void setPayload(String payload) {
		Simulador.payload = payload;
	}

	public static float getTempXML() {
		return tempXML;
	}

	public static void setTempXML(float tempXML) {
		Simulador.tempXML = tempXML;
	}

	public static float getTempHTML() {
		return tempHTML;
	}

	public static void setTempHTML(float tempHTML) {
		Simulador.tempHTML = tempHTML;
	}

	public static float getTempJSON() {
		return tempJSON;
	}

	public static void setTempJSON(float tempJSON) {
		Simulador.tempJSON = tempJSON;
	}

	public static float getTempUL() {
		return tempUL;
	}

	public static void setTempUL(float tempUL) {
		Simulador.tempUL = tempUL;
	}

	public static float getTempLora() {
		return tempLora;
	}

	public static void setTempLora(float tempLora) {
		Simulador.tempLora = tempLora;
	}

	public static float getTempTeros() {
		return tempTeros;
	}

	public static void setTempTeros(float tempTeros) {
		Simulador.tempTeros = tempTeros;
	}

	public static int getI() {
		return i;
	}

	public static void setI(int i) {
		Simulador.i = i;
	}

	public int getDuracao() {
		return duracao;
	}

	public void setDuracao(int duracao) {
		this.duracao = duracao;
	}

	public int getQtdSensores() {

		return qtdSensores;
	}

	public void setQtdSensores(int qtdSensores) {
		this.qtdSensores = qtdSensores;
	}

	public int getPeriodicidade() {
		return periodicidade;
	}

	public void setPeriodicidade(int periodicidade) {
		this.periodicidade = periodicidade;
	}

	public static String getProtocolo() {
		return protocolo;
	}

	public static void setProtocolo(String protocolo) {
		Simulador.protocolo = protocolo;
	}

	public float getTemperatura() {
		return temperatura;
	}

	public void setTemperatura(float temperatura) {
		this.temperatura = temperatura;
	}

	public static String formataPayload(String protocolo1, float temperatura1) throws IOException {
		String payload = "";

		setProtocolo(protocolo1);
		float temperatura = temperatura1;

		if (getProtocolo().equals("XML")) {

			payload = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><measure device=\"dht22\" key=\"4jggokgpepnvsb2uv4s40d59ov\"><t value=\""
					+ temperatura + "\" />" + "<ti value = \"XML\" /></measure>";
			// System.out.println("payload = "+payload);
		} else if (getProtocolo().equals("HTML")) {

			payload = "<!DOCTYPE html><div id=\"temperature\">" + temperatura + "</div><div id=\"ti\">HTML</div>";
		} else if (getProtocolo().equals("JSON")) {

			payload = "{\"t\":" + "\"" + temperatura + "\",\"ti\":\"JSON\"}"; // +"\""+ ", \"ti\": \"JSON\"}";
		} else if (getProtocolo().equals("UL")) {

			payload = "t|" + temperatura + "|ti|UL";

		} else if (getProtocolo().equals("TEROS12")) {

			payload = "t|" + temperatura + "|ti|TEROS12";
		} else if (getProtocolo().equals("INDEFINIDO")) {

			// int id = (int) (this.temperatura);
			// String nameSensorIndefinido = "sensorIndefinido_" + id;
			// SensorIndefinido sensorIndefinido = new SensorIndefinido(id,
			// nameSensorIndefinido);

			// payload = sensorIndefinido.fornecerPayload();
			// payload = sensorIndefinido.fornecerPayload();
			System.out.println("Sensor INDEFINIDO.....");
		} else if (getProtocolo().equals("LORA")) {

			String loraData = "ts|" + String.valueOf(temperatura) + "|ti|lora";
			String textoSerializado = converteBase64(loraData);
			payload = "{\"applicationID\":\"5\",\"applicationName\":\"mestrado_simulacao\",\"deviceName\":\"DHT11\",\"devEUI\":\"221597e4529df57d\","
					+ "\"rxInfo\":[{\"gatewayID\":\"000000ffff001000\",\"name\":\"ExpGW\",\"rssi\":-57,\"loRaSNR\":7,\"location\":{"
					+ "\"latitude\":0,\"longitude\":0,\"altitude\":0}}],\"txInfo\":{\"frequency\":915000000,\"dr\":5},\"adr\":false,"
					+ "\"fCnt\":0,\"fPort\":1,\"data\":\"" + textoSerializado + "\"}";
		}
		return payload;
	}

	private static String converteBase64(String loraData) {

		return Base64.getEncoder().encodeToString(loraData.getBytes());

	}

	public static void main(String[] args) throws InterruptedException, IOException, MqttException {
		Simulador s = new Simulador(50, 3, 60000);
		System.out.println("Args[0] qtde de sensores = " + args[0]);
		System.out.println("Args[1] periodicidade = " + args[1]);
		System.out.println("Args[2] tempo em ms = " + args[2]);
		System.out.println("Quantidade de sensores = " + s.getQtdSensores());
		System.out.println("Periodicidade = " + s.getPeriodicidade());
		System.out.println("Duracao em milisegundos = " + s.getDuracao());
		// Aqui eu defino o tempo que vai durar as requisi��es.
		// No caso se eu coloco totalTime = 12000 ir� durar 12 segundos...
		long totalTime = s.getDuracao(); // em milisegundos. 1min = 60000 ms
		long startTime = System.currentTimeMillis();
		boolean toFinish = false;
		setI(1);
		String protocolo = "";

		final Subscriber subscriber = new Subscriber();
		subscriber.start();

		// ============================Links uteis
		// ===================================================//
		// https://stackoverflow.com/questions/4950966/a-better-way-to-run-code-for-a-period-of-time
		// https://www.baeldung.com/spring-webflux-concurrency
		// https://www.devmedia.com.br/threads-paralelizando-tarefas-com-os-diferentes-recursos-do-java/34309
		// https://www.devmedia.com.br/trabalhando-com-threads-em-java/28780
		// ============================Links uteis
		// ===================================================//

		while (!toFinish) {
			for (int j = 0; j < s.getQtdSensores(); j++) {

				System.out.println("Requisição get número = " + getI());

				// Filtro obj = new Filtro();

				// ============================Links uteis
				// ===================================================//
				// create a list of Integer type
				// https://www.geeksforgeeks.org/randomly-select-items-from-a-list-in-java/
				// https://www.codegrepper.com/code-examples/java/java+random+from+array
				// https://stackoverflow.com/questions/8115722/generating-unique-random-numbers-in-java/8115744
				// ============================Links uteis
				// ===================================================//
				String[] listaDeProtocolos = { "XML", "HTML", "JSON", "UL", "INDEFINIDO", "TEROS12", };// , "LORA" };
				// String protocol = "";

				Random r = new Random();
				int randomNumber = r.nextInt(listaDeProtocolos.length);
				setProtocolo(listaDeProtocolos[randomNumber]);
				// protocol = "";
				// Aqui estou pensando em expandir o tipo de simulador para umidade, pressão,
				// etc...
				tipoDeSimulador = "temperatura";

				if ((getProtocolo().equals("XML"))) {
					// caso seja XML
					Thread txml = new Thread(new Runnable() {
						@Override
						public void run() {

							// caso seja XML
							String nameSensorXML = "sensorXML_DHT11_" + i;
							SensorXML sensorXML = new SensorXML(i, nameSensorXML);
							System.out.println("Nome do sensor = " + sensorXML.getName());

							// System.out.println("Payload completo XML = " + sensorXML.fornecerPayload());
							// preciso publicar o payload completo no broker

							// if (tipoDeSimulador.equals("temperatura")) {
							System.out.println("temperatura do XML ======== " + getTempXML());

							Template templateXML = new Template();
							try {
								payload = templateXML.geraTemplate(getProtocolo(), getTempXML());
							} catch (IOException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}

							System.out.println("payload formatado XML = " + payload);

							// }
							/*
							 * if ((s.getQtdSensores()) >= 6) { int testes = s.getQtdSensores()/6;
							 * SensorXML[testes] sensorXML = new SensorXML(1, nameSensorXML); for (int j =
							 * 0; j < s.getQtdSensores(); j++) {
							 * 
							 * SensorXML[testes ] sensorXML = new SensorXML(j, nameSensorXML+j); }
							 * 
							 * }
							 */
							Publisher p = new Publisher();
							try {
								p.publica("1" + payload);
							} catch (MqttException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}

							// System.out.println("XML = " + protocolo);
							Relatorio.setTipo(1);
							System.out.println("Contagem de sensores XML = " + Relatorio.contabiliza());

						}
					});
					txml.start();
					txml.join();
					// Caso seja HTML
				} else if (getProtocolo().equals("HTML")) {
					Thread thtml = new Thread(new Runnable() {
						@Override
						public void run() {
							String nameSensorHTML = "sensorHTML_DHT11_" + i;
							SensorHTML sensorHTML = new SensorHTML(i, nameSensorHTML);
							System.out.println("nome do sensor = " + sensorHTML.getName());

							// if (tipoDeSimulador.equals("temperatura")) {

							Template templateHTML = new Template();
							try {
								payload = templateHTML.geraTemplate(getProtocolo(), getTempHTML());
							} catch (IOException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}

							System.out.println("payload formatado HTML = " + payload);
							// }

							Publisher p = new Publisher();
							try {
								p.publica("2" + payload);
							} catch (MqttException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}

							Relatorio.setTipo(2);
							System.out.println("Contagem de sensores HTML = " + Relatorio.contabiliza());

						}
					});
					thtml.start();
					thtml.join();
					// Caso seja JSON
				} else if (getProtocolo().equals("JSON")) {
					Thread tjson = new Thread(new Runnable() {
						@Override
						public void run() {
							String nameSensorJSON = "sensorJSON_DHT11_" + i;
							SensorJSON sensorJSON = new SensorJSON(i, nameSensorJSON);
							System.out.println("nome do sensor = " + sensorJSON.getName());

							// System.out.println("payload completo JSON = " +
							// sensorJSON.fornecerPayload());

							// if (tipoDeSimulador.equals("temperatura")) {

							Template templateJSON = new Template();
							try {
								payload = templateJSON.geraTemplate(getProtocolo(), getTempJSON());
							} catch (IOException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}

							System.out.println("payload formatado JSON = " + payload);
							// }

							Publisher p = new Publisher();
							try {
								p.publica("3" + payload);
							} catch (MqttException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}

							Relatorio.setTipo(3);
							System.out.println("Contagem de sensores JSON = " + Relatorio.contabiliza());

						}
					});
					tjson.start();
					tjson.join();
					// Caso seja UL
				} else if (getProtocolo().equals("UL")) {
					Thread tul = new Thread(new Runnable() {
						@Override
						public void run() {
							String nameSensorUL = "sensorUL_DHT11_" + i;
							SensorUL sensorUL = new SensorUL(i, nameSensorUL);
							System.out.println("nome do sensor = " + sensorUL.getName());

							// if (tipoDeSimulador.equals("temperatura")) {

							Template templateUL = new Template();
							try {
								payload = templateUL.geraTemplate(getProtocolo(), getTempUL());
							} catch (IOException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}

							System.out.println("payload formatado UL = " + payload);
							// }

							Publisher p = new Publisher();
							try {
								p.publica("4" + payload);
							} catch (MqttException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}

							Relatorio.setTipo(4);
							System.out.println("Contagem de sensores UL = " + Relatorio.contabiliza());

						}
					});
					tul.start();
					tul.join();
					// Caso seja Aleatório
				} else if (getProtocolo().equals("INDEFINIDO")) {
					Thread tindef = new Thread(new Runnable() {
						@Override
						public void run() {
							// tempo de parsing...
							String nameSensorIndefinido = "sensorIndefinido_" + i;
							// System.out.println("Temperatura = " + tempIndefinido);
							SensorIndefinido sensorIndefinido = new SensorIndefinido(i, nameSensorIndefinido);
							// fim parsing...
							// System.out.println("payload completo INDEFINIDO = " +
							// sensorIndefinido.fornecerPayload());

							Publisher p = new Publisher();
							try {
								p.publica("5" + sensorIndefinido.fornecerPayload());
							} catch (MqttException | IOException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}

							Relatorio.setTipo(5);
							System.out.println("Contagem de sensores INDEFINIDOS = " + Relatorio.contabiliza());

						}
					});
					tindef.start();
					tindef.join();
					// Caso seja LoRa
				} else if (getProtocolo().equals("LORA")) {
					Thread tlora = new Thread(new Runnable() {
						@Override
						public void run() {
							System.out.println("LoRa = " + getProtocolo());
							String nameSensorLora = "sensorLora_DHT11_" + i;
							SensorLora sensorLora = new SensorLora(i, nameSensorLora);

							// if (tipoDeSimulador.equals("temperatura")) {

							Template templateLora = new Template();
							try {

								payload = templateLora.geraTemplate(getProtocolo(), getTempLora());
							} catch (IOException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}

							System.out.println("payload formatado LoRa = " + payload);
							// }

							Publisher p = new Publisher();
							// p.publica("6"+payload);
							try {
								p.publica(payload);
							} catch (MqttException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}

							Relatorio.setTipo(6);
							System.out.println("Contagem de sensores LoRa = " + Relatorio.contabiliza());

						}
					});
					tlora.start();
					tlora.join();
				} else if (getProtocolo().equals("TEROS12")) {
					Thread tteros = new Thread(new Runnable() {
						@Override
						public void run() {
							String nameSensorTEROS12 = "sensorTEROS12_" + i;
							SensorTeros sensorTeros12 = new SensorTeros(i, nameSensorTEROS12);
							System.out.println("nome do sensor = " + sensorTeros12.getName());

							// if (tipoDeSimulador.equals("temperatura")) {

							Template templateTeros = new Template();

							try {
								payload = templateTeros.geraTemplate(getProtocolo(), getTempTeros());
							} catch (IOException e1) {
								// TODO Auto-generated catch block
								e1.printStackTrace();
							}

							System.out.println("payload formatado Teros12 = " + payload);
							// }

							Publisher p = new Publisher();
							try {
								p.publica("7" + payload);
							} catch (MqttException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}

							Relatorio.setTipo(7);
							System.out.println("Contagem de sensores Teros12 = " + Relatorio.contabiliza());

						}
					});
					tteros.start();
					tteros.join();
					// Caso seja Aleatório
				} else {
					System.out.println("Protocolo INDEFINIDO");
				}
				i++;
				// System.out.println("contador = "+i++);

				toFinish = (System.currentTimeMillis() - startTime >= s.getDuracao());
				System.out.println("Tempo atual em milisegundos: " + System.currentTimeMillis());
				System.out.println("Tempo de inicio: " + startTime);
				System.out.println("Tempo total para que finalize = " + s.getDuracao());
				System.out.println("Tempo para encerramento: " + (System.currentTimeMillis() - startTime));
			}
			System.out.println(
					"CONSEGUI PUBLICAR " + getI() + " SENSORES EM " + (System.currentTimeMillis() - startTime));

			// Aqui eu coloco de quanto em quanto tempo sera realizada a requisicao.
			// Nesse caso a cada 3segundos ira fazer a requisicao.
			Thread.sleep(s.getPeriodicidade() * 1000);
		}
		System.out
				.println("CONSEGUI PUBLICAR " + getI() + " SENSORES EM 60 segundos ou " + s.duracao + " milisegundos");
		Relatorio.mostraRelatorio();
	}

}
